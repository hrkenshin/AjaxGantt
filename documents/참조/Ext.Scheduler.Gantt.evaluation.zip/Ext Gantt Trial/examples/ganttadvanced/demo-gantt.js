DemoGanttPanel = Ext.extend(Sch.TreeGanttPanel, {
    leftLabelField : 'Name',
    rightLabelField : 'Responsible',
    highlightWeekends : false,
    showTodayLine : true,
    loadMask : true,
    trackMouseOver : false,
    stripeRows : true,
    timeColumnDefaults : { width : 150 },
    
    initComponent : function() {
        // Add some extra functionality
        this.plugins = this.plugins.concat([new Sch.gantt.plugins.TaskContextMenu(), new Sch.plugins.Pan()]);
        
        Ext.apply(this, {
            // Define an HTML template for the tooltip
            tooltipTpl : new Ext.XTemplate(
                '<h4 class="tipHeader">{Name}</h4>',
                '<table class="taskTip">', 
                    '<tr><td>Start:</td> <td align="right">{[values.StartDate.format("y-m-d")]}</td></tr>',
                    '<tr><td>End:</td> <td align="right">{[values.EndDate.format("y-m-d")]}</td></tr>',
                    '<tr><td>Progress:</td><td align="right">{PercentDone}%</td></tr>',
                '</table>'
            ).compile(),
            
            // Define the static columns
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [
                    {
                        header : 'Tasks', 
                        sortable:true, 
                        dataIndex : 'Name', 
                        locked : true,
                        width:180, 
                        editor : new Ext.form.TextField(),
                        renderer : function (v, m, r) {
                            if (r.get('IsLeaf')) {
                                m.css = 'task';
                            } else {
                                m.css = 'parent';
                            }
                            return v;
                        }
                    },
                    {
                        header : 'Start', 
                        sortable:true, 
                        width:90, 
                        dataIndex : 'StartDate', 
                        locked : true,
                        renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                        editor : new Ext.form.DateField({
                            format: 'm/d/y'
                        })
                    },
                    {
                        header : 'Duration', 
                        sortable:true, 
                        width:50, 
                        dataIndex : 'Duration', 
                        renderer: function(v, m, r) {
                            var d = Math.round(Date.getDurationInHours(r.get('StartDate'), r.get('EndDate'))/12) / 2;
                            if (d > 0) {
                                return d + 'd';
                            }
                        }, 
                        locked : true, 
                        editor: new Ext.ux.form.SpinnerField({
                            allowBlank:false,
                            minValue : 0,
                            decimalPrecision: 1,
                            incrementValue : 1
                        })
                    },
                    {
                        header : '% Done', 
                        sortable:true, 
                        width:50, 
                        dataIndex : 'PercentDone', 
                        renderer: function(v, m, r) {
                            return typeof v === 'number' ? (v + '%') : '';
                        }, 
                        locked : true, 
                        editor: new Ext.ux.form.SpinnerField({
                            allowBlank:false,
                            minValue : 0,
                            maxValue : 100,
                            incrementValue : 10
                        })
                    }
                ]
            }),
            
             // Define the buttons that are available for user interaction
            tbar : [{
                xtype: 'buttongroup',
                title: 'Navigation',
                columns: 2,
                defaults: {
                    scale: 'large'
                },
                items: [{
                    iconCls : 'icon-prev',
                    scope : this,
                    handler : function() {
                        this.setView(this.getStart().add(Date.MONTH, -1), this.getEnd().add(Date.MONTH, -1));
                    }
                },
                {
                    iconCls : 'icon-next',
                    scope : this,
                    handler : function() {
                        this.setView(this.getStart().add(Date.MONTH, 1), this.getEnd().add(Date.MONTH, 1));
                    }
                }]
            },
            {
                xtype: 'buttongroup',
                title: 'View tools',
                columns: 2,
                defaults: {
                    scale: 'small'
                },
                items: [
                    {
                        text : 'Collapse all',
                        iconCls : 'icon-collapseall',
                        scope : this,
                        handler : function() {
                            this.store.collapseAll();
                        }
                    },
                    {
                        text : 'Zoom to fit',
                        iconCls : 'zoomfit',
                        handler : function() {
                            var first = new Date(9999,0,1), last = new Date(0);
                            
                            this.store.each(function(r) {
                                first = Date.min(r.get('StartDate'),first);
                                last = Date.max(r.get('EndDate'),last);
                            });
                            
                            first = first.clone();
                            first.setDate(1);
                            first = first.add(Date.MONTH, -1);
                            last = last.clone();
                            last.setDate(1);
                            last = last.add(Date.MONTH, 1);
                            
                            this.setView(first, last, 'monthAndQuarters');
                            this.fitTimeColumns();
                        },
                        scope : this
                    },
                    {
                        text : 'Expand all',
                        iconCls : 'icon-expandall',
                        scope : this,
                        handler : function() {
                            this.store.expandAll();
                        }
                    }
                ]
            },
            {
                xtype: 'buttongroup',
                title: 'View resolution',
                columns: 2,
                defaults: {
                    scale: 'small'
                },
                items: [{
                        id : 'span1',
                        text: '10 weeks',
                        scope : this,
                        handler : function() {
                            var s = this.getStart();
                            
                            // Start the week on a Monday
                            while(s.getDay() !== 1) {
                                s = s.add(Date.DAY, -1);
                            }
                            this.setView(s, s.add(Date.WEEK, 10), 'weekAndDayLetters');
                        }
                    },
                    {
                        id : 'span2',
                        text: '6 months',
                        scope : this,
                        handler : function() {
                            var s = this.getStart();
                            s.setDate(1);
                            this.setView(s, s.add(Date.MONTH, 6), 'monthAndQuarters');
                        }
                    },
                    {
                        id : 'span3',
                        text: '1 year',
                        scope : this,
                        handler : function() {
                            var s = this.getStart();
                            s.setMonth(0);
                            s.setDate(1);
                            this.setView(s, s.add(Date.MONTH, 12), 'monthAndQuarters');
                        }
                    }
                ]},
                '->',
                {
                    xtype: 'buttongroup',
                    title: 'Try some features...',
                    columns : 2,
                    items: [
                    {
                        text : 'Highlight critical chain',
                        iconCls : 'togglebutton',
                        scope : this,
                        enableToggle : true,
                        handler : function(btn) {
                            this.el.toggleClass('show-critical-chain');
                            if (btn.pressed) {
                                this.highlightCriticalPaths(true);
                            } else {
                                this.unhighlightCriticalPaths(true);
                            }
                        }
                    },
                    {
                        iconCls : 'action',
                        text : 'Highlight tasks longer than 7 days',
                        scope : this,
                        handler : function(btn) {
                            this.store.each(function(task) {
                                if (Date.getDurationInDays(task.get('StartDate'), task.get('EndDate')) > 7) {
                                    var el = this.getElementFromEventRecord(task);
                                    el && el.frame('lime');
                                }
                            }, this);
                        }
                    },
                    {
                        iconCls : 'togglebutton',
                        text : 'Filter: Tasks with progress < 30%',
                        scope : this,
                        enableToggle : true,
                        toggleGroup : 'filter',
                        handler : function(btn) {   
                            if (btn.pressed) {
                                this.store.filterBy(function(task) {
                                    return task.get('PercentDone') < 30;
                                });
                            } else {
                                this.store.clearFilter();
                            }
                        }
                    },
                    {
                        iconCls : 'action',
                        text : 'Scroll to last task',
                        scope : this,
                        handler : function(btn) {
                            var last = this.store.getAt(this.store.getCount()-1);
                            this.getView().scrollEventIntoView(last);
                        }
                    },
                    {
                        iconCls : 'togglebutton',
                        text : 'Cascade changes',
                        scope : this,
                        enableToggle : true,
                        handler : function(btn) {
                            this.cascadeChanges = btn.pressed;
                        }
                    },
                    {
                        xtype : 'textfield',
                        emptyText : 'Search for task...',
                        scope : this,
                        width:150,
                        enableKeyEvents : true,
                        listeners : {
                            keyup : {
                                fn : function(field) {
                                    this.store.filter('Name', field.getValue(), true, false);
                                },
                                scope : this
                            }
                        }
                    }]
                }
            ]
        });
        
        DemoGanttPanel.superclass.initComponent.apply(this, arguments);
    }
});