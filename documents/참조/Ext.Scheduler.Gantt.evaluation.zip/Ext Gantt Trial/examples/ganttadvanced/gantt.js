Ext.ns('App');

Ext.onReady(function() {
    Ext.QuickTips.init();
    
    Ext.override(Sch.ViewBehaviour.MonthView, {
        timeResolution : 720
    });
    
    Ext.override(Sch.ViewBehaviour.WeekView, {
        timeResolution : 720
    });
    
    App.Gantt.init();
});


App.Gantt = {
    
    // Initialize application
    init : function(serverCfg) {        
        this.gantt = this.createGantt();
        
        var vp = new Ext.Viewport({
            layout : 'border',
            items : [
                {
                    region : 'north',
                    contentEl : 'north',
                    padding: '15px'
                },
                this.gantt
            ]
        });
        this.initEvents();
    },
    
    initEvents : function() {
        var g = this.gantt;
        
        g.on({
            'beforeedit': this.beforeEdit, 
            'afteredit': this.afterEdit, 
            'timeheaderdblclick' : this.onTimeHeaderDoubleClick,
            scope : this
        });
    },
    
    onTimeHeaderDoubleClick : function(g, start, end, e) {
        var columnType = 'monthAndQuarters';
        
        if (start.getYear() === end.getYear() && (end.getMonth() - start.getMonth() === 1))
        {
            // Only showing one month, show day numbers
            columnType = 'monthAndDays';
        }
        g.setView(start, end, columnType, Sch.ViewBehaviour.MonthView);
    },
    
    beforeEdit : function(o) {
        // Set the duration field to help the editor get the value
        o.cancel = (o.field === 'Duration' || o.field === 'StartDate') && !o.record.store.isLeafNode(o.record);
        
        if (!o.cancel && o.field === 'Duration') {
            var r = o.record,
                durationDays = Math.round(Date.getDurationInHours(r.get('StartDate'), r.get('EndDate'))/12) / 2;
            
            r.set('Duration', durationDays);
        }
    },
    
    afterEdit : function(o) {
        if (o.field === 'Duration') {
            var start = o.record.get('StartDate');
            o.record.set('EndDate', start.add(Date.HOUR, o.value * 24));
        } else if (o.field === 'StartDate') {
            var dur = o.record.get('EndDate') - o.originalValue;
            o.record.set('EndDate', o.value.add(Date.MILLI, dur));
        }
    },
    
    createGantt : function() {
      
        var store = new Ext.ux.maximgb.tg.AdjacencyListStore({
            defaultExpanded : true,
    	    autoLoad : true,
            proxy : new Ext.data.HttpProxy({
                url : 'tasks.json',
                method:'GET'
            }),
		    reader: new Ext.data.JsonReader({idProperty : 'Id'}, [
                    // Mandatory fields
     	            {name:'Id'},
                    {name:'Name', type:'string'},
                    {name:'StartDate', type : 'date', dateFormat:'c'},
                    {name:'EndDate', type : 'date', dateFormat:'c'},
                    {name:'PercentDone'},
                    {name:'ParentId', type: 'auto'},
                    {name:'IsLeaf', type: 'bool'},

                    // Your task meta data goes here
                    {name:'Responsible'},
                    {name:'Duration'}
                ]
            )
        });
        
        var dependencyStore = new Ext.data.JsonStore({   
            idProperty : 'Id',
            autoLoad : true,
            proxy : new Ext.data.HttpProxy({
                url : 'dependencies.json',
                method:'GET'
            }),
            fields : [
                // 3 mandatory fields
                {name:'From'},
                {name:'To'},
                {name:'Type'}
            ]
        });
        
        var g = new DemoGanttPanel({
            region : 'center',
            store : store,
            dependencyStore : dependencyStore,
            
            viewModel : {
                start : new Date(2010,0,4), 
                end : new Date(2010,0,4).add(Date.WEEK, 20), 
                columnType : 'weekAndDayLetters',
                viewBehaviour : Sch.ViewBehaviour.WeekView
            }
        });
        
        return g;
    }
};

