Ext.ns('App');

Ext.onReady(function() {App.Scheduler.init(); });

App.Scheduler = {
    
    // Initialize application
    init : function(serverCfg) {  
        Ext.BLANK_IMAGE_URL = 'http://extjs.cachefly.net/ext-3.1.1/resources/images/default/s.gif';
        Ext.QuickTips.init();      
        this.grid = this.createGrid();
        
        this.initEvents();
    },
    
    initEvents : function() {
        var g = this.grid;
        
        g.on({
            'timeheaderdblclick' : this.onTimeHeaderDoubleClick,
            scope : this
        });
    },
    
    onTimeHeaderDoubleClick : function(g, start, end, e) {
        var days = Math.round(Date.getDurationInDays(start, end));
        
        if (days === 7) {
            g.setView(start, end, 'weekAndDays', Sch.ViewBehaviour.WeekView);
        } else {
            g.setView(start, end, 'monthAndQuarters', Sch.ViewBehaviour.MonthView);
        }
    },
    
    createGrid : function() {
        var start = new Date(2010,0,1),
            end = start.add(Date.MONTH, 10);
       
        var store = new Ext.ux.maximgb.tg.AdjacencyListStore({
            defaultExpanded : false,
    	    autoLoad : true,
            proxy : new Ext.data.HttpProxy({
                url : 'tasks.json',
                method:'GET'
            }),
		    reader: new Ext.data.JsonReader({idProperty : 'Id'}, [
                    // Mandatory fields
     	            {name:'Id'},
                    {name:'Name', type:'string'},
                    {name:'StartDate', type : 'date', dateFormat:'c'},
                    {name:'EndDate', type : 'date', dateFormat:'c'},
                    {name:'PercentDone'},
                    {name:'ParentId', type: 'auto'},
                    {name:'IsLeaf', type: 'bool'},

                    // Your task meta data goes here
                    {name:'Responsible'}
                ]
            )
        });
        
        var dependencyStore = new Ext.data.JsonStore({   
            autoLoad : true,
            proxy : new Ext.data.HttpProxy({
                url : 'dependencies.json',
                method:'GET'
            }),
            fields : [
                // 3 mandatory fields
                {name:'From'},
                {name:'To'},
                {name:'Type'}
            ]
        });
        
        var g = new Sch.TreeGanttPanel({
            height : 600,
            width: 1000,
            renderTo : Ext.getBody(),
            leftLabelField : 'Name',
            highlightWeekends : false,
            showTodayLine : true,
            loadMask : true,
            enableDependencyDragDrop : false,
            
            tooltipTpl : new Ext.XTemplate(
                '<h4 class="tipHeader">{Name}</h4>',
                '<table class="taskTip">', 
                    '<tr><td>Start:</td> <td align="right">{[values.StartDate.format("y-m-d")]}</td></tr>',
                    '<tr><td>End:</td> <td align="right">{[values.EndDate.format("y-m-d")]}</td></tr>',
                    '<tr><td>Progress:</td><td align="right">{PercentDone}%</td></tr>',
                '</table>'
            ).compile(),
            
            viewModel : {
                start : start, 
                end : end, 
                columnType : 'monthAndQuarters',
                viewBehaviour : Sch.ViewBehaviour.MonthView
            },
            
            // Setup your static columns
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [
                   {
                        header : 'Tasks', 
                        sortable:true, 
                        dataIndex : 'Name', 
                        locked : true,
                        width:250, 
                        editor : new Ext.form.TextField()
                   }
                ]
            }),
            store : store,
            dependencyStore : dependencyStore,
            trackMouseOver : false,
            plugins : [new Sch.plugins.Pan()],
            stripeRows : true
        });
        
        return g;
    }
};
