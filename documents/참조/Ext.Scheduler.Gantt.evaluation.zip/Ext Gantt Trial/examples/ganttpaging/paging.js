Ext.ns('App');

Ext.onReady(function() {App.Scheduler.init(); });

App.Scheduler = {
    
    // Initialize application
    init : function(serverCfg) {  
        Ext.BLANK_IMAGE_URL = 'http://extjs.cachefly.net/ext-3.1.1/resources/images/default/s.gif';
        Ext.QuickTips.init();      
        this.grid = this.createGrid();
        
        this.grid.store.load({
            params : {
                start : 0,
                limit : 25
            }
        });
    },
    
    createGrid : function() {
        var start = new Date(2010,0,1),
            end = start.add(Date.MONTH, 10);
        
        var store = new Ext.ux.maximgb.tg.AdjacencyListStore({
            defaultExpanded : true,
            proxy : new Ext.ux.data.PagingMemoryProxy(taskData),
		    reader: new Ext.data.JsonReader({idProperty : 'Id'}, [
                    // Mandatory fields
     	            {name:'Id'},
                    {name:'Name', type:'string'},
                    {name:'StartDate', type : 'date', dateFormat:'c'},
                    {name:'EndDate', type : 'date', dateFormat:'c'},
                    {name:'PercentDone'},
                    {name:'ParentId', type: 'auto'},
                    {name:'IsLeaf', type: 'bool'}
                ]
            )
        });
        
        var g = new Sch.TreeGanttPanel({
            height : 600,
            width: 1000,
            renderTo : Ext.getBody(),
            leftLabelField : 'Name',
            highlightWeekends : false,
            showTodayLine : false,
            enableDependencyDragDrop : false,
            
            viewModel : {
                start : start, 
                end : end, 
                columnType : 'monthAndQuarters',
                viewBehaviour : Sch.ViewBehaviour.MonthView
            },
            
            // Setup your static columns
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [
                   {
                        header : 'Tasks', 
                        sortable:true, 
                        dataIndex : 'Name', 
                        locked : true,
                        width:250
                   }
                ]
            }),
            store : store,
            trackMouseOver : false,
            stripeRows : true,
            plugins : [new Sch.plugins.Pan()],
            
            // paging bar on the bottom
            bbar: new Ext.PagingToolbar({
                pageSize: 25,
                store: store,
                displayInfo: true,
                displayMsg: 'Displaying tasks {0} - {1} of {2}',
                emptyMsg: "No tasks to display"
            })
        });
        
        return g;
    }
};

// Records are already sorted for this example, no need to re-sort
Ext.override(Ext.ux.maximgb.tg.AbstractTreeStore, {
    applyTreeSort : Ext.emptyFn
});