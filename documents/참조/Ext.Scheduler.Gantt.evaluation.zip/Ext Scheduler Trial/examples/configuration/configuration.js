Ext.ns('App');

Ext.onReady(function() {
    App.Scheduler.init();
});

Ext.override(Sch.ViewBehaviour.Base, {
    dateFormat : 'm/d/Y'
});

Ext.override(Sch.ViewBehaviour.DayView, {
    dateFormat : 'm/d/Y g:i A'
});

Ext.override(Sch.ViewBehaviour.HourView, {
    dateFormat : 'g:i A'
});

Ext.override(Sch.ViewBehaviour.WeekView, {
    dateFormat : 'm/d/Y'
});

Ext.override(Sch.ViewBehaviour.MonthView, {
    dateFormat : 'm/d/Y'
});

Ext.override(Sch.ViewBehaviour.YearView, {
    dateFormat : 'm/d/Y'
});

App.Scheduler = {
    
    // Initialize application
    init : function() {
        
        var today = new Date();
        
        today.clearTime();
        
        this.grid = this.createGrid();
        this.grid.setView(today, today.add(Date.DAY, 14), 'day', Sch.ViewBehaviour.DayView);
        
        this.grid.store.loadData([
                {Id : 'r1', Name : 'Mike'},
                {Id : 'r2', Name : 'Linda'},
                {Id : 'r3', Name : 'Don'},
                {Id : 'r4', Name : 'Karen'},
                {Id : 'r5', Name : 'Doug'},
                {Id : 'r6', Name : 'Peter'}
        ]);
        
        this.grid.eventStore.loadData([
                {Id : 'e10', ResourceId: 'r1', Date1 : today.add(Date.DAY, 2), Date4 : today.add(Date.DAY, 10)},
                {Id : 'e11', ResourceId: 'r2', Date1 : today.add(Date.DAY, 2), Date4 : today.add(Date.DAY, 11)},
                {Id : 'e21', ResourceId: 'r3', Date1 : today.add(Date.DAY, 5), Date4 : today.add(Date.DAY, 12)},
                {Id : 'e33', ResourceId: 'r6', Date1 : today.add(Date.DAY, 4), Date4 : today.add(Date.DAY, 14)}
        ]);
        
        this.grid.on('viewchange', function(g) {
            Ext.getCmp('resolutionLabel').setText(g.getViewResolution());
        });
    },
    
    createGrid : function() {
        
        // Store holding all the categories
        var resourceStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Name', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id'},
                {name: 'Name'}
            ]
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id', type:'string'},
                {name: 'ResourceId'},
                {name: 'StartDate', type : 'date', mapping:'Date1'},
                {name: 'EndDate', type : 'date', mapping:'Date4'},
                
                {name: 'Title'}
            ]
        });
        
        var g = new Sch.SchedulerPanel({
            border : true,
            height:250,
            width: 900,
            resizeHandles : 'none',
            renderTo : 'grid-configuration',
            trackMouseOver : false,
            stripeRows : true,
            
            // Setup static columns
            columns : [
               {header : 'Name', sortable:true, width:100, dataIndex : 'Name'}
            ],
            
            viewConfig : {
                forceFit:true
            },
            
            store : resourceStore,
            eventStore : eventStore,
            tbar : [
                {
                    text : '15 minutes',
                    handler : function() {
                        var s = g.getStart();
                        s.clearTime();
                        s.setHours(11);
                        var e = s.add(Date.HOUR, 10);
                        g.setView(s, e, 'quarterMinutes', Sch.ViewBehaviour.HourView);
                    }
                },
                {
                    text : 'Hours',
                    handler : function() {
                        var s = g.getStart();
                        s.clearTime();
                        s.setHours(11);
                        var e = s.add(Date.HOUR, 10);
                        g.setView(s, e, 'hour', Sch.ViewBehaviour.HourView);
                    }
                },
                {
                    text : 'Hours and days',
                    handler : function() {
                        var s = g.getStart();
                        s.clearTime();
                        s.setHours(11);
                        var e = s.add(Date.HOUR, 10);
                        g.setView(s, e, 'hourAndDay', Sch.ViewBehaviour.HourView);
                    }
                },
                {
                    text : 'Days',
                    handler : function() {
                        var s = g.getStart(),
                            e = s.add(Date.DAY, 3);
                            
                        g.setView(s, e, 'day', Sch.ViewBehaviour.DayView);
                    }
                },
                {
                    text : 'Days and weeks',
                    handler : function() {
                        var s = g.getStart(),
                            e = s.add(Date.DAY, 14);
                          
                        g.setView(s, e, 'dayAndWeeks', Sch.ViewBehaviour.DayView);
                    }
                },
                {
                    text : 'Weeks',
                    handler : function() {
                        var s = g.getStart();
                        
                        while (s.getDay() != 1) {
                            s = s.add(Date.DAY, -1);
                        }  
                        var e = s.add(Date.DAY, 42);
                        
                        g.setView(s, e, 'week', Sch.ViewBehaviour.WeekView);
                    }
                },
                {
                    text : 'Week and days',
                    handler : function() {
                        var s = g.getStart();
                        
                        while (s.getDay() != 1) {
                            s = s.add(Date.DAY, -1);
                        }  
                        var e = s.add(Date.DAY, 42);
                         
                        g.setView(s, e, 'weekAndDays', Sch.ViewBehaviour.WeekView);
                    }
                },
                {
                    text : 'Week and months',
                    handler : function() {
                        var s = g.getStart();
                        
                        while (s.getDay() != 1) {
                            s = s.add(Date.DAY, -1);
                        }  
                        var e = s.add(Date.DAY, 42);
                          
                        g.setView(s, e, 'weekAndMonths', Sch.ViewBehaviour.WeekView);
                    }
                },
                {
                    text : 'Months',
                    handler : function() {
                        var s = g.getStart(),
                            e = s.add(Date.MONTH, 12);
                          
                        g.setView(s, e, 'month', Sch.ViewBehaviour.MonthView);
                    }
                },
                 {
                    text : 'Months and days',
                    handler : function() {
                        var s = g.getStart(),
                            e = s.add(Date.MONTH, 1);
                          
                        g.setView(s, e, 'monthAndDays', Sch.ViewBehaviour.MonthView);
                    }
                },
                {
                    text : 'Months and quarters',
                    handler : function() {
                        var s = g.getStart(),
                            e = s.add(Date.MONTH, 12);
                          
                        g.setView(s, e, 'monthAndQuarters', Sch.ViewBehaviour.MonthView);
                    }
                },
                {
                    text : 'Years',
                    handler : function() {
                        var s = g.getStart(),
                            e = s.add(Date.YEAR, 10);
                          
                        g.setView(s, e, 'year', Sch.ViewBehaviour.YearView);
                    }
                }
            ],
            
            bbar : [
                {
                    xtype : 'label',
                    text : 'Resolution (minutes): '
                },
                {
                    xtype : 'label',
                    id : 'resolutionLabel',
                    text : '60'
                }
            ],
            
            listeners : {
                dragcreateend : {
                    fn : function(g, data, e) {
                        var b = new this.grid.eventStore.recordType({
                            ResourceId : data.record.get('Id'),
                            StartDate : data.startDate,
                            EndDate : data.endDate
                        });
                        
                        this.grid.eventStore.add(b);
                    },
                    scope : this
                }
            }
        });
        
        return g;
    }
};
