var data = [
    {
        Id : 1,
        Name : 'Research',
        Category : 'Project 1'
    },
    {
        Id : 2,
        Name : 'Interviews',
        Category : 'Project 1'
    },
     {
        Id : 3,
        Name : 'Build use cases',
        Category : 'Project 1'
    },
    {
        Id : 4,
        Name : 'Implementation phase 1',
        Category : 'Project 1'
    },
    {
        Id : 5,
        Name : 'Implementation phase 2',
        Category : 'Project 1'
    },
    {
        Id : 6,
        Name : 'Documentation',
        Category : 'Project 1'
    }
];

var today = new Date();
today.clearTime();

var eventData = [
        {Id : 'e1', ResourceId: 1, StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)},
        {Id : 'e2', ResourceId: 2, StartDate : today.add(Date.DAY, 6), EndDate : today.add(Date.DAY, 8)},
        {Id : 'e3', ResourceId: 3, StartDate : today.add(Date.DAY, 8), EndDate : today.add(Date.DAY, 12)},
        {Id : 'e6', ResourceId: 4, StartDate : today.add(Date.DAY, 12), EndDate : today.add(Date.DAY, 14)},
        {Id : 'e7', ResourceId: 5, StartDate : today.add(Date.DAY, 14), EndDate : today.add(Date.DAY, 17)},
        {Id : 'e8', ResourceId: 6, StartDate : today.add(Date.DAY, 17), EndDate : today.add(Date.DAY, 23)},
        {Id : 'e11', ResourceId: 11, StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)}
];

var eventData2 = [
        {Id : 'e1', ResourceId: 1, StartDate : today.add(Date.DAY, 1), EndDate : today.add(Date.DAY, 4)},
        {Id : 'e2', ResourceId: 2, StartDate : today.add(Date.DAY, 4), EndDate : today.add(Date.DAY, 5)},
        {Id : 'e3', ResourceId: 3, StartDate : today.add(Date.DAY, 4), EndDate : today.add(Date.DAY, 12)},
        {Id : 'e6', ResourceId: 4, StartDate : today.add(Date.DAY, 6), EndDate : today.add(Date.DAY, 14)},
        {Id : 'e7', ResourceId: 5, StartDate : today.add(Date.DAY, 13), EndDate : today.add(Date.DAY, 17)},
        {Id : 'e8', ResourceId: 6, StartDate : today.add(Date.DAY, 7), EndDate : today.add(Date.DAY, 14)},
        {Id : 'e11', ResourceId: 11, StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)}
];
        