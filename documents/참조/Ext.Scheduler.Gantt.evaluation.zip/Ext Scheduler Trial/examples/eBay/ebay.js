Ext.ns('App');

Ext.onReady(function() {
    if (typeof console === 'undefined') {
        console = {
            log : Ext.log,
            error : Ext.log
        };
    }
    
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    init : function() {
        
        var start = new Date();
        
        // Make sure interval starts on a monday. 
        while (start.getDay() != 1) {
            start = start.add(Date.DAY, -1);
        }
        
        this.grid = this.createGrid();
        
        this.grid.setView(start.add(Date.DAY, -7), start.add(Date.DAY, 14), 'day', Sch.ViewBehaviour.DayView, this.renderer);
        
        var loader = Ext.get('loader');
        
        // Quick hack to show load indicator
        this.grid.eventStore.on({
            'beforeload' : loader.show.createDelegate(loader),
            'load' : loader.fadeOut.createDelegate(loader),
            scope : this
        });
        
        this.grid.eventStore.load({
            params: {
                "paginationInput.pageNumber" : 0,          
                "paginationInput.entriesPerPage": 20
            }
        });
    },
        
    renderer : function (item, r, row, col, ds, index) {
        return item.data;
    },
    
    createGrid : function() {
        
        // Store holding all the categories
        var itemStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Name', direction: "ASC"},
            root : 'findItemsAdvancedResponse[0].searchResult[0].item',
            idProperty : 'Id',
            fields : [
                {name: 'Id', mapping: 'itemId[0]'},
                {name: 'Name', mapping: 'title[0]'}
            ]
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            proxy: new Ext.data.ScriptTagProxy({
                callbackParam : 'callback',
                url: 'http://svcs.ebay.com/services/search/FindingService/v1',
                listeners : {
                    beforeload : function(proxy, p) {
                        p['paginationInput.pageNumber'] = 1 + Math.floor(p['paginationInput.pageNumber'] / p['paginationInput.entriesPerPage']);
                    }
                }
            }),
            baseParams : {
                "OPERATION-NAME" : 'findItemsAdvanced',
                "SERVICE-VERSION" : '1.0.0',
                "SECURITY-APPNAME" : 'MatsBryn-c034-4a5d-90f1-2f4cd5a72edb',
                "RESPONSE-DATA-FORMAT" : 'JSON',
                "REST-PAYLOAD" : true,
                "itemFilter(0).name" : "Currency",
                "itemFilter(0).value" : "USD"
            },
            paramNames : {
                start : "paginationInput.pageNumber",       // The parameter name which specifies the start row    
                limit : "paginationInput.entriesPerPage"    // The parameter name which specifies number of rows to return
            },
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            root : 'findItemsAdvancedResponse[0].searchResult[0].item',
            totalProperty: 'findItemsAdvancedResponse[0].paginationOutput[0].totalEntries[0]',
            fields : [
                {name: 'Id', type:'string', mapping: 'itemId[0]'},
                {name: 'ResourceId', mapping: 'itemId[0]'},
                {name: 'Title', mapping: 'title[0]'},
                {name: 'Price', mapping: 'sellingStatus[0].currentPrice[0].__value__'},
                {name: 'Location', mapping: 'location[0]'},
                {name: 'GalleryUrl', convert : function(v, r) {
                    return r.galleryURL ? r.galleryURL[0] : Ext.BLANK_IMAGE_URL;
                }},
                {name: 'ViewItemUrl', mapping: 'viewItemURL[0]'},
                {name: 'StartDate', mapping : 'listingInfo[0].startTime[0]', type:'date', dateFormat : "c"},
                {name: 'EndDate', mapping : 'listingInfo[0].endTime[0]', type:'date', dateFormat : "c"}
            ]
        });
        
        eventStore.on('beforeload', function(store, options) {
            options.params.keywords = Ext.getCmp('searchField').getValue();
        });
        
        eventStore.on('load', function() {
            itemStore.loadData(eventStore.reader.jsonData);
        });
        
        var g = new Sch.SchedulerPanel({
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            border : true,
            height:600,
            autoWidth:true,
            renderTo : 'grid-ebay',
            disableSelection : true,
            trackMouseOver : false,
            
            viewConfig : {
                emptyText : 'No auctions found'
            },
            
            columns : [],
            
            eventTemplate : new Ext.Template(
                '<div id="{id}" style="width:{width}px;left:{leftOffset}px" class="sch-event {cls}">',
                       '<img src="{GalleryUrl}" class="thumb"/>',
                    '<div class="sch-event-inner">',
                       '<div class="title"><a href="{ViewItemUrl}" target="_blank" title="Click to view item in a new window">{Title}</a></div>',
                       '<div class="price">{Price} {Currency} USD</div>',
                       '<div class="location">{Location}</div>',
                   '</div>',
                '</div>'
            ).compile(),
                    
            store : itemStore,
            eventStore : eventStore,
            
            tbar : [
                new Ext.form.TwinTriggerField({
                    id : 'searchField',
                    value : 'car porsche',
                    handler : eventStore.load,
                    scope : eventStore,
                    allowEmpty : false,
                    trigger1Class:'x-form-clear-trigger',
                    trigger2Class:'x-form-search-trigger',
                    onTrigger1Click : function(){
                        this.el.dom.value = '';
                    },

                    onTrigger2Click : function(){
                        if (this.getValue()) {
                            eventStore.reload();
                        } else {
                            alert ('You must enter a text');
                        }
                    },
                    listeners : {
                        'specialkey' : function(f, e){
                            if(e.getKey() == e.ENTER){
                                this.onTrigger2Click();
                            }
                        }
                    }
                }),
                '                          ',
                {   
                    xtype : 'tbtext',
                    text : '<img src="../../images/loading2.gif" id="loader" style="display:none"/>'
                }
            ]
        });
        
        return g;
    }
};

// Handle inconstistencies in the eBay response object
Ext.override(Ext.data.JsonReader, {
    readRecords : function(o){
        /**
         * After any data loads, the raw JSON data is available for further custom processing.  If no data is
         * loaded or there is a load exception this property will be undefined.
         * @type Object
         */
        this.jsonData = o;
        if(o.metaData){
            this.onMetaChange(o.metaData);
        }
        var s = this.meta, Record = this.recordType,
            f = Record.prototype.fields, fi = f.items, fl = f.length, v;

        var root = this.getRoot(o) || [], c = root.length, totalRecords = c, success = true;
        if(s.totalProperty){
            v = parseInt(this.getTotal(o), 10);
            if(!isNaN(v)){
                totalRecords = v;
            }
        }
        if(s.successProperty){
            v = this.getSuccess(o);
            if(v === false || v === 'false'){
                success = false;
            }
        }

        // TODO return Ext.data.Response instance instead.  @see #readResponse
        return {
            success : success,
            records : this.extractData(root, true), // <-- true to return [Ext.data.Record]
            totalRecords : totalRecords
        };
    }
});