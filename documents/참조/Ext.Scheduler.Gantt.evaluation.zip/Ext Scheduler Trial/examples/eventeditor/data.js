// Some dummy data

staff = [
    {
        Id : 'a',
        Name : 'Rob',
        Type : 'Sales'
    },
    {
        Id : 'b',
        Name : 'Mike',
        Type : 'Sales'
    },
    {
        Id : 'c',
        Name : 'Kate',
        Type : 'Product manager'
    },
    {
        Id : 'd',
        Name : 'Lisa',
        Type : 'Developer'
    },
    {
        Id : 'e',
        Name : 'Dave',
        Type : 'Developer'
    },
    {
        Id : 'f',
        Name : 'Arnold',
        Type : 'Developer'
    },
    {
        Id : 'g',
        Name : 'Lee',
        Type : 'Marketing'
    },
    {
        Id : 'h',
        Name : 'Jong',
        Type : 'Marketing'
    }
];

tasks = [
    {
        ResourceId : 'a',
        Title : 'Some task', 
        StartDate : '2010-05-22 10:00',
        EndDate : '2010-05-22 12:00',
        Location : 'Some office'
    },
    {
        ResourceId : 'b',
        Title : 'Some other task', 
        StartDate : '2010-05-22 13:00',
        EndDate :  '2010-05-22 16:00',
        Location : 'Home office'
    },
    {
        ResourceId : 'c',
        Title : 'A basic task', 
        StartDate : '2010-05-22 9:00',
        EndDate :  '2010-05-22 13:00',
        Location : 'Customer office'
    }
];