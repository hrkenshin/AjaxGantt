exampleData = [
   
    ['Basic examples', 'Configuration', 'configuration/configuration.html', 'cog.png'],
    ['Basic examples', 'Grouping view', 'grouping/grouping.html', 'cog.png'],
    ['Basic examples', 'Locking + grouping view', 'lockingandgrouping/lockingandgrouping.html', 'cog.png'],
    ['Basic examples', 'Scrolling programmatically', 'scrollto/scrollto.html', 'cog.png'],
    
    ['Advanced examples', 'HTML5 & CSS3', 'html5/html5.html', 'cog.png'],
    ['Advanced examples', 'Web Desktop', 'desktop/desktop.html', 'cog.png'],
    ['Advanced examples', 'Utilization Chart', 'local/local.html', 'cog.png'],
    ['Advanced examples', 'External Drag & Drop', 'externaldragdrop/externaldragdrop.html', 'cog.png'],
    ['Advanced examples', 'Experimental: Excel Export', 'excelexport/excelexport.html', 'cog.png'],
    
    ['Plugins', 'EventEditor', 'eventeditor/editor.html', 'puzzle.png'],
    ['Plugins', 'Lines and Zones', 'linesandzones/linesandzones.html', 'puzzle.png'],
    ['Plugins', 'Timegap', 'timegap/timegap.html', 'puzzle.png'],
    ['Plugins', 'Summary Column', 'columnsummary/columnsummary.html', 'puzzle.png'],
    ['Plugins', 'Panning', 'pan-plugin/pan-plugin.html', 'puzzle.png'],
    ['Plugins', 'Drag Selector', 'dragselector-plugin/dragselector-plugin.html', 'puzzle.png'],
    
    ['Mashups', 'eBay', 'ebay/ebay.html', 'ebay.jpg'],
    ['Mashups', 'Google Calendar', 'googlecalendar/googlecalendar.html', 'calendar.gif'],
    ['Mashups', 'Yahoo Upcoming', 'Upcoming/upcoming.html', 'upcoming.png'],
    ['Mashups', 'Rapha�l', 'raphael/raphael.html', 'raphael.png'],
    ['Mashups', 'WAMI - Speech recognition', 'speech/speech.html', 'speech.png'],
    ['Mashups', 'Meetup', 'meetup/meetup.html', 'meetup.png'],
    ['Mashups', 'RadioTime', 'radiotime/radiotime.html', 'radiotime.png']
    
];