Ext.ns('App');

Ext.onReady(function() {
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    init : function() {
        
        var today = new Date();
        
        today.clearTime();
        
        this.grid = this.createGrid();
        this.grid.setView(today, today.add(Date.DAY, 10), 'day', Sch.ViewBehaviour.DayView, this.renderer);
        
        this.grid.store.loadData([
                {Id : 'r1', Name : 'Mike'},
                {Id : 'r2', Name : 'Linda'},
                {Id : 'r3', Name : 'Don'},
                {Id : 'r4', Name : 'Karen'},
                {Id : 'r5', Name : 'Doug'},
                {Id : 'r6', Name : 'Peter'}
        ]);
        
        this.grid.eventStore.loadData([
                {Id : 'e10', ResourceId: 'r1', Title : 'Assignment 1', StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)},
                {Id : 'e11', ResourceId: 'r2', Title : 'Assignment 1', StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)},
                {Id : 'e21', ResourceId: 'r3', Title : 'Assignment 2', StartDate : today.add(Date.DAY, 5), EndDate : today.add(Date.DAY, 9)},
                {Id : 'e22', ResourceId: 'r4', Title : 'Assignment 2', StartDate : today.add(Date.DAY, 5), EndDate : today.add(Date.DAY, 9)},
                {Id : 'e32', ResourceId: 'r5', Title : 'Assignment 3', StartDate : today.add(Date.DAY, 4), EndDate : today.add(Date.DAY, 8)},
                {Id : 'e33', ResourceId: 'r6', Title : 'Assignment 3', StartDate : today.add(Date.DAY, 4), EndDate : today.add(Date.DAY, 8)}
        ]);
    },
    
    renderer : function (item, r, row, col, ds, index) {
        return {
            text : item.get('Title')
        };
    },
    
    createGrid : function() {
        
        // Store holding all the categories
        var resourceStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Name', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id'},
                {name: 'Name'}
            ]
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id', type:'string'},
                {name: 'ResourceId'},
                {name: 'StartDate', type : 'date'},
                {name: 'EndDate', type : 'date'},
                
                {name: 'Title'}
            ]
        });
        
        var g = new Sch.SchedulerPanel({
            border : true,
            height:300,
            width: 800,
            renderTo : 'grid-excelexport',
            trackMouseOver : false,
            stripeRows : true,
            resizeHandles : 'none',
            enableDragCreation : false,
            
            // Setup static columns
            columns : [
               {header : 'Name', sortable:true, width:100, dataIndex : 'Name'}
            ],
            
            viewConfig : {
                forceFit:true
            },
            
            plugins : [
                new Sch.plugins.ExcelExport()
            ],
            store : resourceStore,
            eventStore : eventStore,
            buttonAlign : 'center',
            buttons : [
                {
                    scale: 'large',
                    iconCls : 'excel',
                    text : 'Export schedule to Excel',
                    handler : function(btn) {
                        g.exportToExcel();
                    },
                    scope : this
                }
            ]
        });
        
        return g;
    }
};
