google.load("gdata", "1");

Ext.ns('App');

Ext.onReady(function() {
    Ext.QuickTips.init();
    
    if (typeof console === 'undefined') {
        console = {
            log : Ext.log,
            error : Ext.log
        };
    }
    App.Scheduler.init();
});

App.Scheduler = {
    
    // Initialize application
    init : function() {
        
        var start = new Date();
        
        this.grid = this.createGrid();
        this.grid.setView(start, start.add(Date.DAY, 7), 'dayAndHours', Sch.ViewBehaviour.DayView, this.renderer);
        
        this.gService = new google.gdata.calendar.CalendarService('exampleCo-exampleApp-1');
        
        // Add some dummy data
        this.addCalendar('mats@mankz.com');
        this.addCalendar('egtovnheg2kg2v4eq7lbrgbm1g@group.calendar.google.com');
        this.addCalendar('lt5tsrugvhceecl61ervg34u3c@group.calendar.google.com');
        this.addCalendar('07efbagvhi6ktqglgq4b956nm0@group.calendar.google.com');
        this.addCalendar('developer-calendar@google.com');
    },
    
    addCalendar : function(email) {
        // Add to resource store right away
        this.grid.store.loadData([
            {Id : email , Title : email}
        ], true);
        
        var query = new google.gdata.calendar.CalendarEventQuery(String.format("http://www.google.com/calendar/feeds/{0}/public/full", email));

        // Create and set the minimum and maximum start time for the date query
        var startMin = new google.gdata.DateTime(new Date().add(Date.MONTH, -3));
        var startMax = new google.gdata.DateTime(new Date().add(Date.MONTH, 3));
        query.setMinimumStartTime(startMin);
        query.setMaximumStartTime(startMax);
        query.setSingleEvents(true);

        this.gService.getEventsFeed(query, this.onFeedLoad.createDelegate(this, [email], true), this.onFeedLoadError.createDelegate(this, [email]));
    },
    
    onFeedLoadError : function(email){
        this.grid.store.remove(this.grid.store.getById(email));
        Ext.Msg.alert('Error', 'No public calendar found with the name ' - email);
    },
    
    onFeedLoad : function(root) {
        var events = [],
            entries = root.feed.entry,
            rowRec = this.grid.store.getById(arguments[arguments.length-1]);
        
        rowRec.store.suspendEvents();
        rowRec.set('Title', root.feed.getTitle().getText());
        rowRec.set('Loaded', true);
        rowRec.store.resumeEvents();
        
        for (var i = 0; i < entries.length; i++) {
            var calendarEntry = entries[i];
            var entryTitle = calendarEntry.getTitle().getText();
            events.push({
                Id : calendarEntry.id.getValue(),
                ResourceId : rowRec.get('Id'),
                Title : entryTitle,
                Description : calendarEntry.content.getText(),
                StartDate : calendarEntry.getTimes()[0].startTime,
                EndDate : calendarEntry.getTimes()[0].endTime
            });
        }
        
        rowRec.commit(true);
        this.grid.eventStore.suspendEvents();
        this.grid.eventStore.loadData(events, true);
        this.grid.eventStore.resumeEvents();
        
        this.grid.getView().refreshRow(rowRec);
    },
    
    // Default renderer, supplies data to be applied to the event template
    renderer : function (event, r, row, col, ds) {
        
        return Ext.apply({
            cls : 'row' + (row%6)
         }, event.data);
    },
    
    createGrid : function() {
        
        // Store holding all the resources
        var resourceStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Id', direction: "ASC"},
            idProperty : 'Id', 
            fields : [
                'Id',
                'Title',
                'Loaded'
            ]
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id'},
                {name: 'ResourceId'},
                {name: 'Title'},
                {name: 'Description'},
                {name: 'StartDate', type : 'date', dateFormat : 'c'},
                {name: 'EndDate', type : 'date', dateFormat : 'c'}
            ]
        });
        
        Sch.ColumnFactory.defaults.width = 300;
        
        var filterField = new Ext.form.TextField({  
            enableKeyEvents : true,
            emptyText : 'Local filter'
        });
        
        filterField.on('keyup', function(field, e){
            if (e.getKey() == e.ESC) {
                field.reset();
            }
            eventStore.filter('Title', this.el.dom.value, true, false);
        });
                
        var g = new Sch.SchedulerPanel({
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            height : 500,
            width : 1000,
            renderTo : 'grid-calendar',
            stripeRows : true,
            enabledHdMenu : false,
            selModel : new Sch.EventSelectionModel({ multiSelect : true }),
            
            // Setup static columns
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [
                   {header : 'Calendar', sortable:true, width:200, dataIndex : 'Title', locked:true, renderer : function(v, m, r) {
                        m.css = 'user';
                        return v;
                   }}
                ]
            }),
            
            view : new Sch.LockingSchedulerView(),
            
            eventTemplate : new Ext.Template(
                '<div id="{id}" style="width:{width}px;left:{leftOffset}px" class="sch-event {cls}">',
                    '<div class="sch-event-inner">{Title}</div>',
                '</div>'
            ).compile(),
            
            store : resourceStore,
            eventStore : eventStore,
            border : true,
            
            tooltipTpl : new Ext.XTemplate(
            '<dl class="eventTip">', 
                '<dt class="sch-clock">When?',
                    '<img src="' + Ext.BLANK_IMAGE_URL + '" class="sch-hourIndicator" style="-moz-transform: rotate({[values.StartDate.getHours() * 30]}deg);-webkit-transform: rotate({[values.StartDate.getHours() * 30]}deg)"/>',
                    '<img src="' + Ext.BLANK_IMAGE_URL + '" class="sch-minuteIndicator" style="-moz-transform: rotate({[values.StartDate.getMinutes() * 6]}deg);-webkit-transform: rotate({[values.StartDate.getMinutes() * 6]}deg)"/>',
                '</dt>',
                '<dd>{[values.StartDate.format("G:i") + " - " + (values.EndDate.format("G:i"))]}</dd>',
                '<dt class="icon-task">What?</dt><dd>{Title}<br/>{Description}</dd>',
            '</dl>').compile(),
                
            tbar : [
                {
                    iconCls : 'icon-prev',
                    handler : function() {
                        g.setView(g.getStart().add(Date.DAY, -1), g.getEnd().add(Date.DAY, -1));
                    }
                },
                '                ',
                {
                    xtype : 'textfield',
                    vtype : 'email',
                    id : 'emailField',
                    width: 200,
                    allowBlank : false,
                    emptyText : 'Enter id (email) of a public google calendar'
                },
                '                ',
                {
                    text : 'Add calendar',
                    iconCls : 'icon-add',
                    handler : function(){
                        var v = Ext.getCmp('emailField');
                        if (!v.isValid()) return;
                        this.addCalendar(v.getValue());
                    },
                    scope : this
                },
                '                ',
                {
                    xtype : 'label',
                    id : 'selectedTime'
                },
                '->',
                filterField,
                '                ',
                {
                    iconCls : 'icon-next',
                    handler : function() {
                        g.setView(g.getStart().add(Date.DAY, 1), g.getEnd().add(Date.DAY, 1));
                    }
                }
            ],
            
            plugins : [
                new Sch.plugins.DragSelector({ beforeStart : Ext.emptyFn })
            ],
            
            trackMouseOver : false
        });
        
        g.getSelectionModel().on('selectionchange', function(sm) {
            var total = 0;
            
            Ext.each(g.getSelectedRecords(), function(r) {
                total += Date.getDurationInHours(r.get('StartDate'), r.get('EndDate'));    
            });
            Ext.getCmp('selectedTime').setText(total > 0 ? (total + ' hours selected') : '');
        });
        return g;
    }
};

