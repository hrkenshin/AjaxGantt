Ext.ns('App');

Ext.onReady(function() {
    Ext.QuickTips.init();
    
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    init : function() {        
        this.grid = this.createGrid();
        this.grid.on('eventcontextmenu', this.onEventContextMenu, this);
        
        var es = this.grid.eventStore;
        
        this.grid.setView(new Date(2007, 0, 1), new Date(2007, 0, 1).add(Date.WEEK, 6), 'weekAndDays', Sch.ViewBehaviour.WeekView, this.renderer);
        
        // Load resource data
        this.grid.store.loadData([
                {Id : 'r1', Name : 'Mike Anderson', Category : 'Consultants', Type:'Full time'},
                {Id : 'r2', Name : 'Kevin Larson', Category : 'Consultants', Type:'Full time'},
                {Id : 'r3', Name : 'Brett Hornbach', Category : 'Consultants', Type:'Full time'},
                {Id : 'r4', Name : 'Lars Holt', Category : 'Consultants', Type:'Full time'},
                {Id : 'r5', Name : 'Fred Arnold', Category : 'Consultants', Type:'Full time'},
                {Id : 'r10', Name : 'Matt Demon', Category : 'Sales', Type:'Full time'},
                {Id : 'r11', Name : 'Karl Lager', Category : 'Testers', Type:'Full time'},
                {Id : 'r12', Name : 'Pete Wilson', Category : 'Testers', Type:'Full time'},
                {Id : 'r13', Name : 'Derek Ronburg', Category : 'Testers', Type:'Full time'},
                {Id : 'r14', Name : 'Alyssa Patterson', Category : 'Testers', Type:'Full time'},
                {Id : 'r15', Name : 'Will Pherrel', Category : 'Testers', Type:'Full time'},
                {Id : 'r16', Name : 'Ofelia Larson', Category : 'Research', Type:'Full time'},
                {Id : 'r17', Name : 'David Mantorp', Category : 'Research', Type:'Full time'},
                {Id : 'r18', Name : 'Ann Withersby', Category : 'Research', Type:'Full time'},
                {Id : 'r20', Name : 'John Dough', Category : 'Research', Type:'Full time'}
        ]);
    },
    
    // Default renderer, supplies data to be applied to the event template
    renderer : function (event, r, row, col, ds) {
        // Add data to be applied to the event template
        return {
            text : event.get('StartDate').format('Y-m-d'),
            cls : r.get('Category')
        };
    },
    
    onEventContextMenu : function(g, rec, e) {
        e.stopEvent();
        
        if (!g.gCtx) {
            g.gCtx = new Ext.menu.Menu({
                items : [
                    {
                        id : 'context-delete',
                        text : 'Delete event',
                        iconCls : 'icon-delete'
                    },
                     {
                        id : 'context-deleteall',
                        text : 'Delete selected events',
                        iconCls : 'icon-deleteall'
                    }
                ]
            });
            
            g.gCtx.on('itemclick', function(item, e) {
                switch (item.id) {
                    case 'context-delete':
                        g.eventStore.remove(g.gCtx.rec);
                    break;
                    
                    case 'context-deleteall':
                        Ext.each(g.getSelectedRecords(), function(r) {
                            g.eventStore.remove(r);
                        });
                    break;
                    
                    default:
                        throw item.id + ' is not a valid menu action';
                    break;
                }
            }, this);
        }
        g.gCtx.rec = rec;
        g.gCtx.showAt(e.getXY());
    },
    
    createGrid : function() {
        
        // Store holding all the resources
        var resourceStore = new Ext.data.GroupingStore({
            groupField : 'Category',
            sortInfo:{field: 'Id', direction: "ASC"},
            reader : new Ext.data.JsonReader({
                idProperty : 'Id'
            }, [
                    'Id', 
                    'Category',
                    'Type',
                    'Name'
                ]
            )
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id', type:'string'},
                {name: 'ResourceId'},
                {name: 'StartDate', type : 'date'},
                {name: 'EndDate', type : 'date'}
            ]
        });
        
        Ext.getBody().addClass('sch-medium');
                
        var g = new Sch.SchedulerPanel({
            height : 500,
            width : 1000,
            renderTo : 'grid-grouping',
            stripeRows : true,
            enabledHdMenu : false,
            selModel : new Sch.EventSelectionModel({ multiSelect : true }),
            
            // Setup your static columns
            columns : [
               {header : 'Staff', sortable:true, width:140, dataIndex : 'Name'},
               {header : 'Employment type', sortable:true, width:140, dataIndex : 'Type'},
               {header : '', width:100, dataIndex : 'Category'}
            ],
            
            view: new Sch.SchedulerGroupingView({
                forceFit : true,
                showSummaryInHeader : true,
                showGroupName : false,
                hideGroupedColumn : true
            }),
            
            store : resourceStore,
            eventStore : eventStore,
            border : true,
            
            listeners : {
                beforedrag : function(dc, e) {
                    return !e.ctrlKey;
                },
                
                dragcreateend : {
                    fn : function(p, data, e) {
                        var b = new this.grid.eventStore.recordType({
                            ResourceId : data.record.get('Id'),
                            StartDate : data.startDate,
                            EndDate : data.endDate
                        });
                        
                        this.grid.eventStore.add(b);
                    },
                    scope : this
                }
            },
            
            tbar : [
                {
                    iconCls : 'icon-prev',
                    scale : 'medium',
                    handler : function() {
                        var start = g.getStart(), end = g.getEnd();
                        
                        start = start.add(Date.WEEK, 6);
                        end = end.add(Date.WEEK, 6);
                            
                        g.setView(start, end);
                    }
                },
                '->',
                {
                    iconCls : 'icon-cleardatabase',
                    tooltip: 'Clear database',
                    scale : 'medium',
                    handler : function() {
                        g.eventStore.removeAll();
                    }
                },
                {
                    iconCls : 'icon-compact',
                    enableToggle : true,
                    toggleGroup: 'rowsize',
                    tooltip: 'Compact size',
                    scale : 'medium',
                    handler : function() {
                        Ext.getBody().removeClass('sch-medium');
                        Ext.getBody().removeClass('sch-large');
                        Ext.getBody().addClass('sch-compact');
                    }
                },
                {
                    iconCls : 'icon-medium',
                    enableToggle : true,
                    toggleGroup: 'rowsize',
                    pressed : true,
                    tooltip: 'Medium size',
                    scale : 'medium',
                    handler : function() {
                        Ext.getBody().removeClass('sch-compact');
                        Ext.getBody().removeClass('sch-large');
                        Ext.getBody().addClass('sch-medium');
                    }
                },
                {
                    iconCls : 'icon-large',
                    enableToggle : true,
                    toggleGroup: 'rowsize',
                    tooltip: 'Full size',
                    scale : 'medium',
                    handler : function() {
                        Ext.getBody().removeClass('sch-compact');
                        Ext.getBody().removeClass('sch-medium');
                        Ext.getBody().addClass('sch-large');
                    }
                },
                {
                    iconCls : 'icon-next',
                    scale : 'medium',
                    handler : function() {
                        var start = g.getStart(), end = g.getEnd();
                        
                        start = start.add(Date.WEEK, -6);
                        end = end.add(Date.WEEK, -6);
                            
                        g.setView(start, end);
                    }
                }
            ],
            
            plugins : new Sch.plugins.DragSelector(),
            
            trackMouseOver : false
        });
        
        return g;
    }
};
