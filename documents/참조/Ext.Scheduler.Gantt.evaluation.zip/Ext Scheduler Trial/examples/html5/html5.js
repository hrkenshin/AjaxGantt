Ext.ns('App');

Ext.onReady(function() {
    Ext.QuickTips.init();
    
    Ext.override(Sch.ViewBehaviour.DayView, {
        dateFormat : 'Y-m-d',
        timeResolution : 24 * 60
    });

    if (Ext.isIE) {
        Ext.Msg.alert('Please note...', 'This example requires a browser with support for HTML5 and CSS3.');
    } else {
        App.Scheduler.init();
    }
});

App.Scheduler = {
    
    // Initialize application
    init : function() {
        this.scheduler = this.createGrid();
        this.scheduler.on('eventclick', this.onEventClick, this);
    },
    
    onEventClick :function(scheduler, record, target, e) {
        if (e.getTarget('.reschedule')) {
            var newStart = record.get('StartDate'), 
                newEnd = record.get('EndDate');
            
            if (e.getTarget('.forward-one')) {
                newStart = newStart.add(Date.DAY, 1);
                newEnd = newEnd.add(Date.DAY, 1);
            } else if (e.getTarget('.back-one')) {
                newStart = newStart.add(Date.DAY, -1);
                newEnd = newEnd.add(Date.DAY, -1);
            } 
            
            if (this.validateBooking([record], scheduler.getResourceByEventRecord(record), newStart, Date.getDurationInMinutes(newStart, newEnd))) {
                record.set('StartDate', newStart);
                record.set('EndDate', newEnd);
            }
        }
    },
    
    renderer : function (item, r, row, col, ds, index) {
        return item.data;
    },
    
    createGrid : function() {
        
        // Store holding all the cabins
        var cabinStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Name', direction: "ASC"},
            idProperty : 'Id',
            data : cabins,
            fields : [
                'Id',
                'Name',
                'ImageUrl',
                'Sleeps'
            ]
        });
        
        // Store holding all the bookings
        var bookingStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            data : bookings,
            fields : [
                {name: 'Id', type:'string'},
                {name: 'GuestName', type:'string'},
                {name: 'ResourceId'},
                {name: 'StartDate', type : 'date'},
                {name: 'NbrNights'},
                {name: 'NbrGuests'},
                
                // Custom calculation of end date
                {name: 'EndDate', type : 'date', convert : function(v, r) { return r.StartDate.add(Date.DAY, r.NbrNights);}}
            ]
        });
        
        var cabinTpl = new Ext.Template(
            '<img class="image" src="images/{ImageUrl}" />',
            '<h3 class="name">{Name}</h3>',
            '<div class="bedImg" title="Sleeps {Sleeps}"><span class="sleeps">{Sleeps}</span></div>'
        );
        
        this.zoneStore = new Ext.data.JsonStore({
            fields : ['StartDate', 'EndDate', 'Cls', 'InnerCls', 'Msg'],
            data : [{
                StartDate : today.add(Date.DAY, 10),
                EndDate : today.add(Date.DAY, 11),
                InnerCls : 'maintenance',
                Msg : 'Maintenance'
            }]
        });
        
        var g = new Sch.SchedulerPanel({
            border : true,
            height:600,
            width: 1040,
            renderTo : Ext.getBody(),
            trackMouseOver : false,
            resizeHandles : 'none',
            enableDragCreation : false,
            autoExpandColumn: 'name', 
            timeColumnDefaults: { width : 70 },
            allowOverlap : false,
            
            // Setup static columns
            columns : [
               {name : 'name', id : 'name', header : 'Name', sortable:true, width:100, dataIndex : 'Name', renderer : function(v,m,r){ return cabinTpl.apply(r.data); }}
            ],
            
            viewModel : {
                start : today, 
                end : today.add(Date.DAY, 11), 
                columnType : 'day', 
                viewBehaviour : Sch.ViewBehaviour.DayView, 
                renderer : this.renderer
            },
            
            store : cabinStore,
            eventStore : bookingStore,
            
            // Specialized template with header and footer
            eventTemplate : new Ext.XTemplate(
                '<div id="{id}" style="width:{width}px;left:{leftOffset}px" class="sch-event {cls}">' +
                       '<div class="bg"></div>',
                       '<div class="bg2"></div>',
                       '<div class="datect"><span class="dayname">{[fm.date(values.StartDate, "l")]}</span><span class="date {[(values.StartDate.getDay() === 0 || values.StartDate.getDay() === 6) ? "weekend" : ""]}">{[fm.date(values.StartDate, "j")]}</span><span class="month">{[fm.date(values.StartDate, "M Y")]}</span></div>' + 
                       '<div class="event-content" style="width:{[values.width-65]}px">',
                            '<dl class="guest-details">',
                                '<dt>Duration</dt>',
                                '<dd>{NbrNights} nights</dd>',
                                '<dt>Tenant:</dt>',
                                '<dd>{GuestName}<span class="nbr-guests" title="{NbrGuests} guests">{NbrGuests}</span></dd>',
                            '</dl>',
                       '</div>',
                       '<div class="reschedule">',
                           '<command src= title="Move to previous day" class="back-one"></command>',
                           '<command src="images/arrows.gif" title="Move to next day" class="forward-one"></command>',
                       '</div>',
                '</div>'
            ).compile(),
            
            plugins : [
                this.zonePlugin = new Sch.plugins.Zones({
                    cls : 'sch-zone',
                    template : new Ext.Template(
                        '<div class="sch-zone blocked" style="left:{left}px;width:{width}px;height:{height}px">',
                            '<div class="block-message">',
                                '<span class="{InnerCls}">{Msg}</span>', 
                            '</div>',
                        '</div>'),
                    store : this.zoneStore 
                })
            ],
            
            dndValidatorFn : this.validateBooking,
            validatorFnScope : this
        });
        
        return g;
    },
    
    validateBooking : function(dragRecords, targetResourceRecord, date, duration, e) {
        var blockedRecord = this.zoneStore.getAt(0);
        return !Date.intersectSpans(blockedRecord.get('StartDate'), blockedRecord.get('EndDate'), date, date.add(Date.MINUTE, duration));
    }
};

var today = new Date().clearTime();
        
var cabins = [
        {Id : 'r1', Name : 'Ski Chateau', ImageUrl : 'house1.jpg', Sleeps : 20},
        {Id : 'r2', Name : 'Cabin Deluxe', ImageUrl : 'house2.jpg', Sleeps : 15},
        {Id : 'r3', Name : 'Cabin Superior', ImageUrl : 'house3.jpg', Sleeps : 10},
        {Id : 'r4', Name : 'Lodge 1', ImageUrl : 'house4.jpg', Sleeps : 8},
        {Id : 'r5', Name : 'Lodge 2', ImageUrl : 'house5.jpg', Sleeps : 8},
        {Id : 'r6', Name : 'Lodge 3', ImageUrl : 'house6.jpg', Sleeps : 8}
];

var bookings = [
    {Id : 'e10', ResourceId: 'r1', GuestName : 'Mattias Backstrom', StartDate : today.add(Date.DAY, 2), NbrNights: 6, NbrGuests: 3, CleaningIncluded : true},
    {Id : 'e11', ResourceId: 'r2', GuestName : 'Axel Hedfors',StartDate : today.add(Date.DAY, 2), NbrNights: 6, NbrGuests: 12, CleaningIncluded : true},
    {Id : 'e21', ResourceId: 'r3', GuestName : 'Bengt Adolfsson', StartDate : today.add(Date.DAY, 1), NbrNights: 6, NbrGuests: 4, CleaningIncluded : true},
    {Id : 'e22', ResourceId: 'r4', GuestName : 'Steven Anderson', StartDate : today.add(Date.DAY, 1), NbrNights: 6, NbrGuests: 5, CleaningIncluded : false},
    {Id : 'e32', ResourceId: 'r5', GuestName : 'Chen Xiong', StartDate : today.add(Date.DAY, 1), NbrNights: 7, NbrGuests: 6, CleaningIncluded : true},
    {Id : 'e33', ResourceId: 'r6', GuestName : 'Douglas Adams', StartDate : today.add(Date.DAY, 4), NbrNights: 4, NbrGuests: 6, CleaningIncluded : false}
];
