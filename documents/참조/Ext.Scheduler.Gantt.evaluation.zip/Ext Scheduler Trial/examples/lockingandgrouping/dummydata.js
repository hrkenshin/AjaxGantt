var data = [
    {
        Id : 1,
        Name : 'Research',
        Category : 'Project 1'
    },
    {
        Id : 2,
        Name : 'Interviews',
        Category : 'Project 1'
    },
     {
        Id : 3,
        Name : 'Build use cases',
        Category : 'Project 1'
    },
    {
        Id : 4,
        Name : 'Implementation phase 1',
        Category : 'Project 1'
    },
    {
        Id : 5,
        Name : 'Implementation phase 2',
        Category : 'Project 1'
    },
    {
        Id : 6,
        Name : 'Documentation',
        Category : 'Project 1'
    },
    {
        Id : 7,
        Name : 'Support',
        Category : 'Project 1'
    },
    {
        Id : 11,
        Name : 'Research',
        Category : 'Project 2'
    },
    {
        Id : 12,
        Name : 'Interviews',
        Category : 'Project 2'
    },
     {
        Id : 13,
        Name : 'Build use cases',
        Category : 'Project 2'
    },
    {
        Id : 14,
        Name : 'Implementation phase 1',
        Category : 'Project 2'
    },
    {
        Id : 15,
        Name : 'Implementation phase 2',
        Category : 'Project 2'
    },
    {
        Id : 16,
        Name : 'Documentation',
        Category : 'Project 2'
    },
    {
        Id : 17,
        Name : 'Support',
        Category : 'Project 2'
    },
    {
        Id : 21,
        Name : 'Research',
        Category : 'Project 3'
    },
    {
        Id : 22,
        Name : 'Interviews',
        Category : 'Project 3'
    },
     {
        Id : 23,
        Name : 'Build use cases',
        Category : 'Project 3'
    },
    {
        Id : 24,
        Name : 'Implementation phase 1',
        Category : 'Project 3'
    },
    {
        Id : 25,
        Name : 'Implementation phase 2',
        Category : 'Project 3'
    },
    {
        Id : 26,
        Name : 'Documentation',
        Category : 'Project 3'
    },
    {
        Id : 27,
        Name : 'Support',
        Category : 'Project 3'
    }
];

var today = new Date();
today.clearTime();

var eventData = [
        {Id : 'e1', ResourceId: 1, StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)},
        {Id : 'e2', ResourceId: 2, StartDate : today.add(Date.DAY, 6), EndDate : today.add(Date.DAY, 8)},
        {Id : 'e3', ResourceId: 3, StartDate : today.add(Date.DAY, 8), EndDate : today.add(Date.DAY, 12)},
        {Id : 'e6', ResourceId: 4, StartDate : today.add(Date.DAY, 12), EndDate : today.add(Date.DAY, 14)},
        {Id : 'e7', ResourceId: 5, StartDate : today.add(Date.DAY, 14), EndDate : today.add(Date.DAY, 17)},
        {Id : 'e8', ResourceId: 6, StartDate : today.add(Date.DAY, 17), EndDate : today.add(Date.DAY, 23)},
        {Id : 'e11', ResourceId: 11, StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)},
        {Id : 'e12', ResourceId: 12, StartDate : today.add(Date.DAY, 6), EndDate : today.add(Date.DAY, 8)},
        {Id : 'e13', ResourceId: 13, StartDate : today.add(Date.DAY, 8), EndDate : today.add(Date.DAY, 12)},
        {Id : 'e16', ResourceId: 14, StartDate : today.add(Date.DAY, 12), EndDate : today.add(Date.DAY, 14)},
        {Id : 'e17', ResourceId: 15, StartDate : today.add(Date.DAY, 14), EndDate : today.add(Date.DAY, 17)},
        {Id : 'e18', ResourceId: 16, StartDate : today.add(Date.DAY, 17), EndDate : today.add(Date.DAY, 23)},
        {Id : 'e21', ResourceId: 21, StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)},
        {Id : 'e22', ResourceId: 22, StartDate : today.add(Date.DAY, 6), EndDate : today.add(Date.DAY, 8)},
        {Id : 'e23', ResourceId: 23, StartDate : today.add(Date.DAY, 8), EndDate : today.add(Date.DAY, 12)},
        {Id : 'e26', ResourceId: 24, StartDate : today.add(Date.DAY, 12), EndDate : today.add(Date.DAY, 14)}
];
        