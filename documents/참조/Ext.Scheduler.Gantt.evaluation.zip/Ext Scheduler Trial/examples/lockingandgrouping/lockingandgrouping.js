Ext.ns('App');

Ext.onReady(function() {
    if (typeof console === 'undefined') {
        console = {
            log : Ext.log,
            error : Ext.log
        };
    }
    
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    init : function() {
        
        var start = new Date();
        start.clearTime();
        
        this.grid = this.createGrid();
        this.win = new Ext.Window({
            layout : 'fit',
            height: 450,
            onEsc : Ext.emptyFn,
            width: 900,
            title : 'Locking and grouping view combined',
            items : [
                this.grid
            ]
        });
        
        this.win.show();
       
        this.grid.setView(start, start.add(Date.DAY, 14), 'dayAndWeeks', Sch.ViewBehaviour.DayView);
    },
    
    createGrid : function() {
        
        // Store holding all the resources
        var resourceStore = new Ext.data.GroupingStore({
            groupField : 'Category',
            sortInfo:{field: 'Id', direction: "ASC"},
            reader : new Ext.data.JsonReader({
                    idProperty : 'Id'
                }, [
                    'Id', 
                    'Category',
                    'Name'
                ]
            ),
            data : data
        });
        
        // Store holding all the events/tasks
        var eventStore = new Ext.data.JsonStore({
            sortInfo : {field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id', 
            fields : [
                // 4 mandatory fields
                {name:'Id', type:'string'},
                {name:'ResourceId'},
                {name:'StartDate', type : 'date', dateFormat:'time'},
                {name:'EndDate', type : 'date', dateFormat:'time'}
                
                // Your task meta data goes here
                // ....
            ],
            data : eventData
        });
        
        var g = new Sch.SchedulerPanel({
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            
            // Setup your static columns
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [
                   {header : 'Tasks', sortable:true, width:170, dataIndex : 'Name', locked : true},
                   {header : '', width:150, dataIndex : 'Category', locked : true}
                ]
            }),
            
            plugins : [new Sch.plugins.Pan()],
            
            view: new Sch.LockingGroupingSchedulerView({
                unlockedGroupHeaderRenderer : this.groupHeaderRenderer, // Draws the grouping header bars
                showGroupName : false,
                hideGroupedColumn : true,
                groupHeaderTpl : new Ext.Template(
                    '&#160;',
                    '<div class="groupHeaderLeft" style="width:{width}px;left:{left}px">',
                        '<div class="groupHeaderRight"></div>',
                    '</div>'
                ).compile()
            }),
            
            store : resourceStore,
            eventStore : eventStore,
            border : false,
            
            bbar : [
                {
                    iconCls : 'icon-prev',
                    scope : this,
                    scale : 'medium',
                    handler : function() {
                        this.grid.setView(this.grid.getStart().add(Date.DAY, -7), this.grid.getEnd().add(Date.DAY, -7));
                    }
                },
                {
                    iconCls : 'icon-next',
                    scope : this,
                    scale : 'medium',
                    handler : function() {
                        this.grid.setView(this.grid.getStart().add(Date.DAY, 7), this.grid.getEnd().add(Date.DAY, 7));
                    }
                }
            ],
            
            listeners : {
                dragcreateend : {
                    fn : function(g, data, e) {
                        var dummyId = 'e' + new Date().getTime(),
                            b = new this.grid.eventStore.recordType({
                            ResourceId : data.record.get('Id'),
                            StartDate : data.startDate,
                            EndDate : data.endDate,
                            Id : dummyId
                        }, dummyId);
                        
                        this.grid.eventStore.add(b);
                    },
                    scope : this
                }
            },
            
            trackMouseOver : false
        });
        
        return g;
    },
    
    // Simple hack to show a ganttish grouping header
    groupHeaderRenderer : function(groupData) {
        var width, 
            left, 
            g = this.grid,
            viewStart = g.getStart(),
            viewEnd = g.getEnd(),
            headerStartDate = new Date(9999, 0, 1), 
            headerEndDate = new Date(0), 
            groupName = groupData.group,
            rs = groupData.rs,
            evtStart,
            evtEnd;
        
        g.eventStore.each(function(r){
            if (rs.indexOf(g.store.getById(r.get('ResourceId'))) < 0) {
                return;
            }
            
            evtStart = r.get('StartDate');
            evtEnd = r.get('EndDate');
            
            if (Date.intersectSpans(evtStart, evtEnd, viewStart, viewEnd)) {
                if (evtStart < headerStartDate) {
                    headerStartDate = evtStart;
                }
                
                if (evtEnd > headerEndDate) {
                    headerEndDate = evtEnd;
                }
            }
        });
        
        if (headerStartDate.getFullYear() === 9999) return groupData.group;
        
        left = g.getXFromDate(Date.max(headerStartDate, viewStart));
        if (left < 0) return groupData.group;
        
        var endX = g.getXFromDate(headerEndDate);
        
        if (!endX) {
            endX = g.getXFromDate(viewEnd);
        }
        
        width = endX - left;
        
        return this.groupHeaderTpl.apply({
            title : groupData.group,
            width : width + 1, 
            left : left
        });
    }
};
