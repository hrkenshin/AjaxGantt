App = {
    
    // Initialize application
    init : function() {
        Ext.QuickTips.init();
        
        var start = new Date().add(Date.MONTH, -1);
        start.clearTime();
        start.setDate(1);
        var end = start.add(Date.MONTH, 4);
        
        var groupTemplate = new Ext.XTemplate(
            '<span class="groupName">{name}</span>' +
            '<span class="members">{members} members</span>' +
            '<span class="location">{city} ({[values.country.toUpperCase()]})</span>'
        );
        
        // Store holding all the user groups
        var groupStore = new Ext.data.JsonStore({
            autoLoad : true,
            proxy: new Ext.data.ScriptTagProxy({
                nocache : false,
                autoAbort : false,
                url: 'http://api.meetup.com/groups.json'
            }),
            baseParams : {
                key : '577d3d6b164953e5b241bc32137646',
                topic : 'ext-js'
            },
            root : 'results',
            fields : [
                {name: 'Id', mapping:'id'},
                {name: 'name'},
                {name: 'rating'},
                {name: 'city'},
                {name: 'country'},
                {name: 'members'}
            ]
        });
        
        // Store holding all the meetings
        var eventStore = new Ext.data.JsonStore({
            proxy: new Ext.data.ScriptTagProxy({
                nocache : false,
                autoAbort : false,
                url: 'http://api.meetup.com/events.json'
            }),
            baseParams : {
                key : '577d3d6b164953e5b241bc32137646',
                after : start.format('mdY'),
                before: end.format('mdY')
            },
            root : 'results',
            fields : [
                {name: 'ResourceId', mapping:'group_id'},
                {name: 'StartDate', mapping:'time', type: 'date', dateFormat : 'D M d g:i:s T Y'},
                {name: 'EndDate', mapping:'time', type: 'date', dateFormat : 'D M d g:i:s T Y'},
                {name: 'name'},
                {name: 'description'},
                {name: 'status'},
                {name: 'time'},
                {name: 'event_url'},
                {name: 'rsvpcount'}
            ]
        });
        
        
        var g = new Sch.SchedulerPanel({
            region : 'center',
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            disableSelection:true,
            height:435,
            width:1200,
            trackMouseOver : false,
            columnLines : false,
            store : groupStore,
            eventStore : eventStore,
            loadMask : true,
            
            eventTemplate : new Ext.XTemplate(
                '<div id="{id}" style="left:{leftOffset}px" class="sch-event {status}">',
                    '<img src="images/pin.png" class="pin"/>',
                    '<div class="eventName"><a href="{event_url}" target="_blank">{name}</a></div>',
                    '<div class="startTime">{[values.StartDate.format("F d G:i")]}</div>',
                    '<div class="rsvps">{rsvpcount} {[values.status === "past" ? "attended" : " members have RSVP\'d"]}</div>',
                '</div>'
            ),
            
            tooltipTpl : new Ext.Template('<h3>{name}</h3><span>{description}</span>'),
            
            viewModel : {
                start : start, 
                end : end, 
                columnType : 'month',
                renderer : function (event) {
                    return event.data;
                }
            },
            
            columns : [ {header : 'Group', sortable:true, width:210, dataIndex : 'name', locked : true, renderer: function(v, m, r) {
                    return groupTemplate.apply(r.data);
                }
            }],            
            viewConfig : { forceFit : true }
        });
        
        groupStore.on('load', function() {
            eventStore.load({
                params : {
                    group_id : groupStore.collect('Id').join(',')
                }
            });
        });
        
        var vp = new Ext.Viewport({
            layout : 'border',
            items : [
                {
                    region : 'north',
                    padding: 15,
                    contentEl : 'north'
                },
                g
            ]
        });
    }
};

Ext.onReady(App.init);
