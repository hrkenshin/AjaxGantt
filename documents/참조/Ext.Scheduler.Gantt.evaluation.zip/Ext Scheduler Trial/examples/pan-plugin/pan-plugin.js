Ext.ns('App');


Ext.onReady(function() {
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Bootstrap function
    init : function() {
        this.grid = this.createGrid();
        
        this.grid.render(Ext.getBody());
    },
    
    createGrid : function() {
            
        // Store holding all the resources
        var resourceStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Id', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                'Id', 
                'Name',
                'Type'
            ]
        });
        
        resourceStore.loadData([
            {
                Id : 'a',
                Name : 'Rob',
                Type : 'Sales'
            },
            {
                Id : 'b',
                Name : 'Mike',
                Type : 'Sales'
            },
            {
                Id : 'c',
                Name : 'Kate',
                Type : 'Product manager'
            },
            {
                Id : 'd',
                Name : 'Lisa',
                Type : 'Developer'
            },
            {
                Id : 'e',
                Name : 'Dave',
                Type : 'Developer'
            },
            {
                Id : 'f',
                Name : 'Arnold',
                Type : 'Developer'
            },
            {
                Id : 'g',
                Name : 'Lee',
                Type : 'Marketing'
            },
            {
                Id : 'h',
                Name : 'Jong',
                Type : 'Marketing'
            }
            
        ]);
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            fields : [
                {name: 'ResourceId'},
                {name: 'StartDate', type : 'date', dateFormat : 'Y-m-d g:i'},
                {name: 'EndDate', type : 'date', dateFormat : 'Y-m-d g:i'}
            ],
            data :  [   // Some inline dummy data
                {
                    ResourceId : 'a',
                    Title : 'Some task', 
                    StartDate : '2010-05-22 10:00',
                    EndDate : '2010-05-22 12:00',
                    Location : 'Some office'
                },
                {
                    ResourceId : 'b',
                    Title : 'Some other task', 
                    StartDate : '2010-05-22 13:00',
                    EndDate :  '2010-05-22 16:00',
                    Location : 'Home office'
                },
                {
                    ResourceId : 'c',
                    Title : 'A basic task', 
                    StartDate : '2010-05-22 9:00',
                    EndDate :  '2010-05-22 13:00',
                    Location : 'Customer office'
                }
            ]
        });
        
        var start = new Date(2010, 4, 22, 6);
        
        var g = new Sch.SchedulerPanel({
            width : 1000,
            height : 400,
            enableDragCreation : false,
            trackMouseOver : false,
            // Setup view configuration
            viewModel : {
                start : start,
                end : start.add(Date.HOUR, 12),
                columnType : 'hourAndDay',
                viewBehaviour : Sch.ViewBehaviour.HourView,
                renderer : this.renderer
            },     
            
            /// Setup your static columns
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [
                    {header : 'Staff', locked : true, width:130, dataIndex : 'Name'}
                ]
            }),
            
            view: new Sch.LockingSchedulerView(),
            
            store : resourceStore,
            eventStore : eventStore,
            
            plugins : [
                new Sch.plugins.Pan({
                    enableVerticalPan : true
                })
            ]
        });
        
        return g;
    }
};

