App = {
    
    // Initialize application
    init : function() {
        Ext.QuickTips.init();
        
        var stationTemplate = new Ext.Template(
            '<span>{Name}</span>' +
            '<img width="100" height="100" src="{image}" />' +
            '<a class="listen" target="_blank" href="{URL}" ext:qtip="Click to listen to {Name}"></a>'
        );
        
        var programTemplate = new Ext.XTemplate(
            '<span class="startTime">{[values.StartDate.format("g:i")]}</span>' + 
            '<span class="programName">{text}</span>' +
            '<span class="duration">{[values.duration < 3600 ? ((values.duration / 60) + "min") : ((Math.round(10*values.duration/3600)/10) + "h")]}</span>'
        );
        
        // Store holding the stations
        var stationStore = new Ext.data.JsonStore({
            idProperty : 'Id',
            fields : [ 'Id', 'Name', 'URL', 'image' ],
            data : stations   // defined in stations.js
        });
        
        // Store holding all the programs
        var programStore = new Ext.data.JsonStore({
            proxy: new Ext.data.ScriptTagProxy({
                nocache : false,
                autoAbort : false,
                url: 'http://opml.radiotime.com/Browse.ashx?c=schedule'
            }),
            baseParams : {
                render : 'json',
                partnerId : 'VPVhT0Sa',
                start : new Date().format('Ymd')
            },
            root : 'body',
            fields : [
                {name: 'ResourceId'},
                {name: 'StartDate', convert : function(v, r) { return Date.parseDate(r.start+"+00:00", 'c'); } },
                {name: 'EndDate', convert : function(v, r) { return Date.parseDate(r.start+"+00:00", 'c').add(Date.SECOND, r.duration);} },
                {name: 'text'},
                {name: 'duration'}
            ]
        });
        
        var start = new Date();
        start.clearTime();
        
        var end = start.add(Date.DAY, 1);
        
        var g = new Sch.SchedulerPanel({
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            disableSelection:true,
            height:315,
            width:1100,
            renderTo : 'grid-radiotime',
            trackMouseOver : false,
            columnLines : false,
            store : stationStore,
            eventStore : programStore,
            
            tooltipTpl : new Ext.XTemplate('{[values.StartDate.format("g:i")]} - {text}').compile(),
            
            viewModel : {
                start : start, 
                end : end, 
                columnType : 'hour',
                renderer : function (event) {
                    return { text : programTemplate.apply(event.data) };
                }
            },
            
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [ {header : 'Station', sortable:true, width:210, dataIndex : 'Name', locked : true, renderer: function(v, m, r) {
                        return stationTemplate.apply(r.data);
                    }
                }]
            }),
            
            view : new Sch.LockingSchedulerView(),
            
            plugins : [
                new Sch.plugins.Lines({
                    store : App.createTimelineStore()
                })
            ]
        });
        
         // Grab each station schedule
        stationStore.each(function(station) {
            
            programStore.load({
                params : {
                    id : station.get('Id')
                },
                callback :  function (rs, o) {
                    // Manually set the station id on each program since the program load response contains no info about this
                    Ext.each(rs, function(r) {
                        r.set('ResourceId', o.params.id); 
                    });
                    
                    if (stationStore.indexOf(stationStore.getById(o.params.id)) === stationStore.getCount() - 1) {
                        // We're done, scroll to current time
                        g.getView().scrollToTime(new Date().add(Date.HOUR, -1), true);
                    }
                },
                add : true
            });
        });
    },
    
    createTimelineStore : function() {
        var timelineStore = new Ext.data.ArrayStore({
            fields: ['Text', 'Date'],
            data : [ ['Current time', new Date()] ] // Just one record with current time
        });
        
        var runner = new Ext.util.TaskRunner();
        
        // Start a new task
        runner.start({
            run: function() {
                timelineStore.getAt(0).set('Date', new Date());
            },
            interval: 10000 // Update line store every 10 seconds
        });
        
        return timelineStore;
    }
};

Ext.onReady(App.init);
