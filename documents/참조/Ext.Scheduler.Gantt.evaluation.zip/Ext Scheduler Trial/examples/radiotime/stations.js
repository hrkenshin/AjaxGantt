stations = [
   {"Id":"s15123","Name":"News Talk FM","URL":"http://opml.radiotime.com/Tune.ashx?id=s15123&formats=mp3&partnerId=VPVhT0Sa&filter=s","type":"audio","image":"http://radiotime-logos.s3.amazonaws.com/s15123q.png","subtext":"Tom Dunne"},
   {"Id":"s22234","Name":"APR","URL":"http://opml.radiotime.com/Tune.ashx?id=s22234&formats=mp3&partnerId=VPVhT0Sa&filter=s","type":"audio","image":"http://radiotime-logos.s3.amazonaws.com/s23344q.png","subtext":"BBC World Business News"},
   {"Id":"s29742","Name":"WJAG","URL":"http://opml.radiotime.com/Tune.ashx?id=s29742&formats=mp3&partnerId=VPVhT0Sa&filter=s","type":"audio","image":"http://radiotime-logos.s3.amazonaws.com/s29742q.png","subtext":"News Talk 78"},
   {"Id":"s34361","Name":"KNRY","URL":"http://opml.radiotime.com/Tune.ashx?id=s34361&formats=mp3&filter=s","type":"audio","image":"http://radiotime-logos.s3.amazonaws.com/s34361q.png","subtext":"Michael Medved Show"}
];