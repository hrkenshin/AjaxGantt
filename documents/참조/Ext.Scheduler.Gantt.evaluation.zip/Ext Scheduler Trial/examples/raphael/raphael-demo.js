Ext.ns('App');

Ext.onReady(function() {
    Ext.QuickTips.init();
    
    if (typeof console === 'undefined') {
        console = {
            log : Ext.log,
            error : Ext.log
        };
    }
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    init : function() {
        this.scheduler = this.createScheduler();
        
        this.scheduler.on('eventdblclick', this.togglePriority, this);
        
        this.chartPanel =  new SummaryChartPanel({
            renderTo: Ext.getBody(),
            width: 700,
            height: 400,
            style:'margin:10px',
            store : this.scheduler.eventStore
        });
        
        this.populateScheduler();
    },
    
    togglePriority : function(s, r) {
        var prios = ['Low', 'Normal', 'Critical'];
        
        r.set('Priority', prios[(prios.indexOf(r.get('Priority')) + 1) % 3]);
    },
    
    populateScheduler : function() {
        var es = this.scheduler.eventStore;
        
        // Load resource data
        this.scheduler.store.loadData([
                {Id : 'r1', Name : 'Machine 1'},
                {Id : 'r2', Name : 'Machine 2'},
                {Id : 'r3', Name : 'Machine 3'},
                {Id : 'r10', Name : 'Machine 4'},
                {Id : 'r11', Name : 'Machine 5'},
                {Id : 'r12', Name : 'Machine 6'}
        ]);
        
        var today = new Date();
        today.clearTime();
        
        // Load event data
        es.load();
        
    },
    
    // Default renderer, supplies data to be applied to the event template
    renderer : function (event) {
        var prio = event.get('Priority');
        return {
            cls : prio,
            style : 'background-color:' + StyleUtil.getPriorityColor(prio),
            text : 'Job #' + event.id
        };
    },
    
    createScheduler : function() {
        
        // Store holding all the resources
        var resourceStore = new Ext.data.Store({
            sortInfo:{field: 'Name', direction: "ASC"},
            reader : new Ext.data.JsonReader({
                idProperty : 'Id'
            }, [
                    'Id', 
                    'Name'
                ]
            )
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            idProperty : 'Id',
            url : 'data.js',
            fields : [
                {name: 'Id'},
                {name: 'ResourceId'},
                {name: 'Priority'},
                {name: 'StartDate', type : 'date', dateFormat : 'Y-m-d'},
                {name: 'EndDate', type : 'date', dateFormat : 'Y-m-d'}
            ]
        });
        
        var start = new Date(2010, 6, 1),
            end = start.add(Date.DAY, 7);
            
        var g = new Sch.SchedulerPanel({
            height : 200,
            width : 700,
            enabledHdMenu : false,
            allowOverlap : false,
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            renderTo: Ext.getBody(),
            
            loadMask : {
                msg : 'Loading jobs...',
                store : eventStore
            },
            viewModel : {
                start : start,
                end : end,
                columnType : 'day',
                viewBehaviour : Sch.ViewBehaviour.DayView,
                renderer : this.renderer.createDelegate(this)
            },
            
            viewConfig : { forceFit : true },
            
            // Setup your static columns
            columns : [
               {header : 'Machines', sortable:true, width:140, dataIndex : 'Name'}
            ],
            
            store : resourceStore,
            eventStore : eventStore,
            border : true,
            trackMouseOver : false
        });
        
        return g;
    }
};

StyleUtil = {
    getPriorityColor : function(prio) {
        switch (prio) {
            case 'Critical' : return 'red'; break;
            case 'Low' : return 'whitesmoke'; break;
            case 'Normal' : return 'lightgreen'; break;
        }
    }
}

SummaryChartPanel = Ext.extend(Ext.BoxComponent, { 
    stroke : "#ccc",
    
    getData : function() {
        var prios = this.store.collect('Priority'),
            values = [],
            store = this.store,
            count = store.getCount();
        
        Ext.each(prios, function(p, i) {
            var sum = store.query('Priority', p).getCount();
            values[i] = sum;
        });
        
        return {
            labels : prios,
            values : values
        };
    },
    
    renderPieChart : function () {
        var cx = this.getWidth() / 2,
            cy =  this.getHeight() / 2,
            r = 100,
            paper = this.paper,
            stroke = this.stroke,
            rad = Math.PI / 180,
            chart = paper.set();
        
        paper.clear();
        
        var data = this.getData(),
            values = data.values,
            labels = data.labels;
            
        function sector(cx, cy, r, startAngle, endAngle, params) {
            var x1 = cx + r * Math.cos(-startAngle * rad),
                x2 = cx + r * Math.cos(-endAngle * rad),
                y1 = cy + r * Math.sin(-startAngle * rad),
                y2 = cy + r * Math.sin(-endAngle * rad);
            return paper.path(["M", cx, cy, "L", x1, y1, "A", r, r, 0, +(endAngle - startAngle > 180), 0, x2, y2, "z"]).attr(params);
        }
        var angle = 0,
            total = 0,
            process = function (j) {
                var value = values[j],
                    angleplus = 360 * value / total,
                    popangle = angle + (angleplus / 2),
                    color = StyleUtil.getPriorityColor(labels[j]),
                    ms = 500,
                    delta = 30,
                    p = sector(cx, cy, r, angle, angle + angleplus, {fill: color, stroke: stroke, "stroke-width": 2}),
                    txt = paper.text(cx + (r + delta + 55) * Math.cos(-popangle * rad), cy + (r + delta + 25) * Math.sin(-popangle * rad), labels[j] + ' (' + value  + ' jobs)').attr({fill: color, stroke: "blue", "font-family": 'Fontin-Sans, Arial', "font-size": "20px"});
                
                p.mouseover(function () {
                    p.animate({scale: [1.1, 1.1, cx, cy]}, ms, "elastic");
                }).mouseout(function () {
                    p.animate({scale: [1, 1, cx, cy]}, ms, "elastic");
                });
                angle += angleplus;
                chart.push(p);
                chart.push(txt);
            };
        for (var i = 0, ii = values.length; i < ii; i++) {
            total += values[i];
        }
        for (var i = 0; i < ii; i++) {
            process(i);
        }
        return chart;
    },

    initComponent : function() {
        this.on('afterrender', this.initRaphael, this);
        
        SummaryChartPanel.superclass.initComponent.call(this);
    },
    
    initRaphael : function() {
        this.paper = Raphael(this.el.dom, this.getWidth(), this.getHeight());
        this.store.on({
            add : this.renderPieChart,
            update : this.renderPieChart,
            remove : this.renderPieChart,
            load : this.renderPieChart,
            scope : this
        });
    }
});
