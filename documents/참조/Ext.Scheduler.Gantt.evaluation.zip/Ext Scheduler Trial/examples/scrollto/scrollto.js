Ext.ns('App');

Ext.onReady(function() {
    Ext.QuickTips.init();
    
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    renderer : function (event, r, row, col, ds) {
        return {
            text : event.get('Title')
        };
    },
    
    init : function() {
        
        // Store holding all the resources
        var resourceStore = new Ext.data.JsonStore({
            idProperty : 'Id',
            sortInfo:{field: 'Name', direction: "ASC"},
            fields : [
                'Id', 
                'Name'
            ],
            data : [
                {Id : 'r1', Name : 'Machine 1'},
                {Id : 'r2', Name : 'Machine 2'},
                {Id : 'r3', Name : 'Machine 3'},
                {Id : 'r4', Name : 'Machine 4'},
                {Id : 'r5', Name : 'Machine 5'},
                {Id : 'r6', Name : 'Machine 6'},
                {Id : 'r7', Name : 'Machine 7'},
                {Id : 'r8', Name : 'Machine 8'},
                {Id : 'r9', Name : 'Machine 9'},
                {Id : 'r10', Name : 'Machine 10'},
                {Id : 'r11', Name : 'Robot 1'},
                {Id : 'r12', Name : 'Robot 2'},
                {Id : 'r13', Name : 'Robot 3'},
                {Id : 'r14', Name : 'Robot 4'},
                {Id : 'r15', Name : 'Robot 5'},
                {Id : 'r16', Name : 'Robot 6'}
            ]
        });
        
        var today = new Date();
        today.clearTime();
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            idProperty : 'Id',
            fields : [
                {name: 'Title', type:'string'},
                {name: 'ResourceId'},
                {name: 'StartDate', type : 'date'},
                {name: 'EndDate', type : 'date'}
            ],
            data : [
                {ResourceId: 'r1', Title : 'Event-1', StartDate : today.add(Date.DAY, 2), EndDate : today.add(Date.DAY, 6)},
                {ResourceId: 'r2', Title : 'Event-2', StartDate : today.add(Date.DAY, 6), EndDate : today.add(Date.DAY, 11)},
                {ResourceId: 'r3', Title : 'Event-3', StartDate : today.add(Date.DAY, 8), EndDate : today.add(Date.DAY, 12)},
                {ResourceId: 'r7', Title : 'Event-4', StartDate : today.add(Date.DAY, 4), EndDate : today.add(Date.DAY, 13)},
                {ResourceId: 'r8', Title : 'Event-5', StartDate : today.add(Date.DAY, 9), EndDate : today.add(Date.DAY, 12)},
                {ResourceId: 'r9', Title : 'Event-6', StartDate : today.add(Date.DAY, 7), EndDate : today.add(Date.DAY, 13)}
                ]
        });
        
        var g = new Sch.SchedulerPanel({
            height : 300,
            width : 700,
            renderTo : Ext.getBody(),
            enabledHdMenu : false,
            allowOverlap : false,
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            
            // Setup your static columns
            colModel : new Ext.ux.grid.LockingColumnModel({
                columns : [
                   {header : 'Machines', sortable:true, width:140, dataIndex : 'Name', locked:true }
                ]
            }),
            
            view: new Sch.LockingSchedulerView(),
            plugins : [new Sch.plugins.Pan()],
            
            viewModel : {
                start : today,
                end : today.add(Date.DAY, 11),
                columnType : 'day',
                renderer : this.renderer
            },
            
            store : resourceStore,
            eventStore : eventStore,
            border : true,
            
            tbar : [
                {
                    text : 'Highlight after scroll',
                    enableToggle : true,
                    pressed : true,
                    id : 'btnHighlight'
                },
                '                     ',
                {
                    xtype : 'combo',
                    id : 'eventCombo',
                    emptyText : 'Select an event to scroll to',
                    store : eventStore.collect('Title'),
                    triggerAction : 'all',
                    editable : false
                },
                {
                    text : 'Scroll to event',
                    iconCls : 'go',
                    handler : function() {
                        var val = Ext.getCmp('eventCombo').getValue(),
                            doHighlight = Ext.getCmp('btnHighlight').pressed,
                            rec = eventStore.getAt(eventStore.find('Title', val));
                         
                         if (!rec) {
                            return;
                         }   
                        g.getView().scrollEventIntoView(rec, doHighlight);
                    }
                },
                '->',
                {
                    xtype : 'combo',
                    id : 'timeCombo',
                    emptyText : 'Select a time to scroll to',
                    store : [[0, 'Today'], [2, '2 days from now'], [10, 'Ten days from now']],
                    triggerAction : 'all',
                    editable : false
                },
                {
                    text : 'Scroll to time',
                    iconCls : 'go',
                    handler : function() {
                        var val = Ext.getCmp('timeCombo').getValue();
                            
                        g.getView().scrollToTime(today.add(Date.DAY, val), true);
                    }
                }  
            ],
            
            trackMouseOver : false
        });
        
        return g;
    }
};
