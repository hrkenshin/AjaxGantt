Ext.ns('App');


Ext.onReady(function() {
    Ext.QuickTips.init();
    
    if (typeof console === 'undefined') {
        console = {
            log : Ext.log,
            error : Ext.log
        };
    }
    
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Bootstrap function
    init : function() {
        
        this.grid = this.createGrid();
        
        this.initStoreEvents();
          
        this.grid.render(Ext.getBody());
        
        this.setupWami();
    },
    
    initStoreEvents : function() {
        this.grid.eventStore.on('add', function (store, records, operation) {
            records[0].markDirty();
            
            // Simulate server delay 1.5 seconds
            records[0].commit.defer(1500, records[0]);
        });
    },
    
    renderer : function (item, resourceRec, row, col, ds) {
        var bookingStart = item.get('StartDate');
        
        return {
            cls : item.get('Type'),
            headerText : bookingStart.format("G:i"),
            footerText : item.get('Title') || '&nbsp;'
        };
    },
    
    createGrid : function() {
            
        // Store holding all the resources
        var resourceStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Id', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                'Id', 
                'Name',
                'Type'
            ]
        });
        
        resourceStore.loadData([
            {
                Id : 'a',
                Name : 'Rob',
                Type : 'Sales'
            },
            {
                Id : 'b',
                Name : 'Mike',
                Type : 'Sales'
            },
            {
                Id : 'c',
                Name : 'Kate',
                Type : 'Product manager'
            },
            {
                Id : 'd',
                Name : 'Lisa',
                Type : 'Developer'
            },
            {
                Id : 'e',
                Name : 'Dave',
                Type : 'Developer'
            },
            {
                Id : 'f',
                Name : 'Arnold',
                Type : 'Developer'
            },
            {
                Id : 'g',
                Name : 'Lee',
                Type : 'Marketing'
            },
            {
                Id : 'h',
                Name : 'Jong',
                Type : 'Marketing'
            }
            
        ]);
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id', type:'string'},
                {name: 'ResourceId'},
                {name: 'Type'},
                {name: 'Title'},
                {name: 'StartDate', type : 'date'},
                {name: 'EndDate', type : 'date'},
                'Location'
            ]
        });
        
        resourceStore.on('exception', function() {
            console.log('resourceStore load exception');
            for (var i = 0; i < arguments.length; i++) {
                console.log(arguments[i]);
            }
        });
        
        eventStore.on('exception', function() {
            console.log('eventStore load exception');
            for (var i = 0; i < arguments.length; i++) {
                console.log(arguments[i]);
            }
        });
        
        var start = new Date();
        
        start.clearTime();
        start.setHours(6);
        
        var g = new Sch.SchedulerPanel({
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            width : 1000,
            height:400,
            sm : new Ext.grid.RowSelectionModel(),
            
            columns : [
                {header : 'Sales staff', sortable:true, width:130, dataIndex : 'Name'}
            ],
            
             // Setup view configuration
            viewModel : {
                start : start,
                end : start.add(Date.HOUR, 12),
                columnType : 'hourAndDay',
                viewBehaviour : Sch.ViewBehaviour.HourView,
                renderer : this.renderer
            },     
            
            // Specialized template with header and footer
            eventTemplate : new Ext.Template(
                '<div id="{id}" style="width:{width}px;left:{leftOffset}px" class="sch-event {cls}">' +
                    '<div class="sch-event-inner">' + 
                       '<span class="sch-event-header">{headerText}</span>' + 
                       '<div class="sch-event-footer">{footerText}</div>' + 
                   '</div>' + 
                '</div>').compile(),
                    
            viewConfig: {
                forceFit:true
            },
            
            store : resourceStore,
            eventStore : eventStore,
            border : true,
            
            trackMouseOver : false
        });
        
        return g;
    },
    
    createBooking : function(type, name, start, duration) {
        var resourceId = this.grid.store.getAt(this.grid.store.find('Name', name, 0, false, false)).get('Id');
        
        var newRec = new this.grid.eventStore.recordType({
            Title: name, 
            ResourceId : resourceId,
            Location : 'Local office',
            StartDate : start,
            Type : type,
            EndDate : start.add(Date.HOUR, duration)
        });
        
        this.grid.eventStore.add(newRec);
    },
    
    onWamiRecognitionResult : function (result) {
        if (result.hyps.length === 0 || result.hyps[0].text === "") return;
        
        var res = result.hyps[0];
        
        Ext.get('parsedtext').update(res.text);
        
        if (!res.aggregate.partial) {
            var words = res.text.split(' '),
                type = words[1],
                person = words[3], 
                start = this.grid.getStart().clone(), 
                duration = parseInt(res.aggregate.kvs.duration, 10);
            
            start.setHours(parseInt(res.aggregate.kvs.starttime, 10));
            
            if (!person || !duration) {
                Ext.Msg.alert('Parsing error', 'Sorry, the words could not be parsed correctly - please try again');
                return;
            }
            
            this.createBooking(type, person, start, duration);
        }
    },
    
    setupWami : function() {
        // JSGF grammar
        var jsgf = 
            "#JSGF V1.0;\n" +
            "grammar TicTacToe;\n" +
            "public <top> = (schedule <activity> with <employee> at <starttime> for <duration> hours)+ ;\n" +
            "<activity>    = call | meeting ;\n" +
            "<employee>    = rob | mike | kate | lisa | dave | arnold | lee | jong ;\n" +
            "<starttime>  = one	{[starttime=13]}\n" +
            "             | two	 {[starttime=14]}\n" +
            "             | three {[starttime=15]}\n" +
            "             | four {[starttime=16]}\n" +
            "             | six {[starttime=6]}\n" +
            "             | seven {[starttime=7]}\n" +
            "             | eight {[starttime=8]}\n" +
            "             | nine {[starttime=9]}\n" +
            "             | ten {[starttime=10]}\n" +
            "             | eleven {[starttime=11]}\n" +
            "             | twelve {[starttime=12]}\n;" +
            "<duration>   = one {[duration=1]}\n" +
            "             | two	{[duration=2]}\n" +
            "             | three {[duration=3]}\n" +
            "              ;";
        var grammar = {"language" : "en-us", "grammar" : jsgf };

        //Audio options.
        //If your application doesn't use speech synthesis, set this to false.
        var audioOptions = {"pollForAudio" : false};

        //Configuration options.
        //sendIncrementalResults: if true, you'll receive "incremental" recognition results as the user speaks
        //sendAggregates: if true, you'll receive a "semantic" interpretation.  Your grammar must follow a specific format.
        var configOptions = {"sendIncrementalResults" : true, "sendAggregates" : true};

        //Handlers are functions which are called for various events:
        var handlers = {"onRecognitionResult" : this.onWamiRecognitionResult.createDelegate(this),  //Speech recognition result available
                        "onError" : function (type, message) {
                                alert("WAMI error: type  = " + type + ", message = " + message);        
                        },  //An error occurred
                        "onTimeout" : function () {
                                alert("WAMI timed out.  Hit reload to start over");
                        }}; //WAMI timed out due to inactivity

        //Create your WAMI application with the settings and grammar we just created
        var myWamiApp = new WamiApp(document.getElementById('AudioContainer'), handlers, "json", audioOptions, configOptions, grammar);
    }
};
