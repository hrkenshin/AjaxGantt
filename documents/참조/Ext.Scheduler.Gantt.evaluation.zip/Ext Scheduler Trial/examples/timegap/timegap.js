Ext.ns('App');

Ext.onReady(function() {
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    init : function() {
        
        var start = new Date(2010,7,14);
        
        start.clearTime();
        
        this.grid = this.createGrid();
        this.grid.setView(start, start.add(Date.DAY, 7), 'day', Sch.ViewBehaviour.DayView, this.renderer);
        
        this.grid.store.loadData([
                {Id : 'r1', Name : 'Mike', Color: 'green'},
                {Id : 'r2', Name : 'Linda', Color: 'red'},
                {Id : 'r3', Name : 'Don', Color: 'blue'},
                {Id : 'r4', Name : 'Karen', Color: 'black'},
                {Id : 'r5', Name : 'Doug', Color: '#777'},
                {Id : 'r6', Name : 'Peter', Color: '#444'}
        ]);
        
        this.grid.eventStore.loadData([
            {"ResourceId":"r1","StartDate":"2010-08-14T00:00:00","EndDate":"2010-08-15T00:00:00","Title":"Assignment 1"},
            {"ResourceId":"r2","StartDate":"2010-08-14T21:00:00","EndDate":"2010-08-15T21:00:00","Title":"Assignment 6"},
            {"ResourceId":"r3","StartDate":"2010-08-19T00:00:00","EndDate":"2010-08-22T00:00:00","Title":"Assignment 2"},
            {"ResourceId":"r5","StartDate":"2010-08-15T00:00:00","EndDate":"2010-08-17T23:00:00","Title":"Assignment 4"},
            {"ResourceId":"r1","StartDate":"2010-08-16T19:00:00","EndDate":"2010-08-17T19:00:00","Title":"Assignment 3"},
            {"ResourceId":"r6","StartDate":"2010-08-15T12:00:00","EndDate":"2010-08-17T12:00:00","Title":"Assignment 5"}
        ]);
    },
    
    resourceRenderer : function (v, m, r) {
        return '<div class="row-colorbox" style="background-color:' + r.get('Color') + '"></div>' + v;
    },
    
    renderer : function (item, r, row, col, ds, index) {
        return {
            text : item.get('Title'),
            style : 'background-color:' + r.get('Color')
        };
    },
    
    createGrid : function() {
        
        // Store holding all the categories
        var resourceStore = new Ext.data.JsonStore({
            sortInfo:{field: 'Name', direction: "ASC"},
            idProperty : 'Id',
            fields : [
                {name: 'Id'},
                {name: 'Name'},
                {name: 'Color'}
            ]
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            fields : [
                {name: 'ResourceId'},
                {name: 'StartDate', type : 'date', dateFormat : 'c'},
                {name: 'EndDate', type : 'date', dateFormat : 'c'},
                
                {name: 'Title'}
            ]
        });
        
        var g = new Sch.SchedulerPanel({
            border : true,
            height:240,
            width: 800,
            renderTo : Ext.getBody(),
            trackMouseOver : false,
            
            // Setup static columns
            columns : [
               {header : 'Name', sortable:true, width:100, dataIndex : 'Name', renderer : this.resourceRenderer}
            ],
            
            viewConfig : {
                forceFit:true
            },
            
            plugins : [new Sch.plugins.TimeGap({
                getZoneCls : function(start, end) {
                    if (Date.getDurationInDays(start, end) > 2) {
                        return 'long-unallocated-slot';
                    }
                }
            })],
            store : resourceStore,
            eventStore : eventStore,
            
            listeners : {
                dragcreateend : {
                    fn : function(p, data, e) {
                        var b = new this.grid.eventStore.recordType({
                            Title: '', 
                            ResourceId : data.record.get('Id'),
                            StartDate : data.startDate,
                            EndDate : data.endDate
                        });
                        
                        this.grid.eventStore.add(b);
                    },
                    scope : this
                }
            },
            
            tbar : [
                {
                    iconCls : 'icon-prev',
                    scale : 'medium',
                    handler : function() {
                        var start, oldStart = g.getStart();
                        
                        start = oldStart.add(Date.DAY, -Date.getDurationInDays(oldStart, g.getEnd()));
                        g.setView(start, oldStart);
                    }
                },
                {
                    iconCls : 'icon-next',
                    scale : 'medium',
                    handler : function() {
                        var end, oldEnd = g.getEnd();
                        end = oldEnd.add(Date.DAY, Date.getDurationInDays(g.getStart(), oldEnd));
                        
                        g.setView(oldEnd, end);
                    }
                }
            ]
        });
        
        return g;
    }
};
