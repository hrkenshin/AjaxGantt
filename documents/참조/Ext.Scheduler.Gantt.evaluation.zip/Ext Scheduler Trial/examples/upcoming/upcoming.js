Ext.ns('App');

Ext.onReady(function() {
    if (typeof console === 'undefined') {
        console = {
            log : Ext.log,
            error : Ext.log
        };
    }
    
    App.Scheduler.init();
});


App.Scheduler = {
    
    // Initialize application
    init : function() {
        
        var start = new Date();
        
        // Make sure interval starts on a monday. 
        while (start.getDay() != 1) {
            start = start.add(Date.DAY, -1);
        }
        
        this.grid = this.createGrid();
        
        var loader = Ext.get('loader');
        
        // Quick hack to show load indicator
        this.grid.eventStore.on({
            'beforeload' : loader.show.createDelegate(loader),
            'load' : loader.fadeOut.createDelegate(loader),
            scope : this
        });
        
        this.grid.eventStore.load({
            params : {
                min_date : start, 
                max_date : start.add(Date.DAY, 7)
            }
        });
        
        this.grid.on('eventclick', this.showEvent, this);
    },
    
    showEvent : function(g, r, t) {
        if (!this.win) {
            this.win = new Ext.Window({
                bodyStyle:'padding:10px',
                height:300,
                width: 300,
                closeAction : 'hide',
                autoScroll:true,
                html : r.get('Description')
            });
        }
        if (this.win.rendered) {
            this.win.body.update(r.get('Description'));
        }
        this.win.setTitle(r.get('Title'));
        this.win.show(t);
    },
        
    renderer : function (item, r, row, col, ds, index) {
        return {
            text : item.get('Title'),
            cls : 'row' + (row % 4)     // Give events some different colors
        };
    },
    
    createGrid : function() {
        
        // Store holding all the categories
        var eventCategoryStore = new Ext.data.JsonStore({
            proxy: new Ext.data.ScriptTagProxy({
                callbackParam : 'callback',
                url: 'http://upcoming.yahooapis.com/services/rest/'
            }),
            baseParams : {
                format : 'json',
                api_key :'8df6674b86',
                method : 'category.getList'
            },
            autoLoad : true,
            sortInfo:{field: 'Name', direction: "ASC"},
            root : 'rsp.category',
            idProperty : 'Id',
            fields : [
                {name: 'Id', mapping: 'id'},
                {name: 'Description', mapping: 'description'},
                {name: 'Name', mapping: 'name'}
            ]
        });
        
        // Store holding all the events
        var eventStore = new Ext.data.JsonStore({
             proxy: new Ext.data.ScriptTagProxy({
                callbackParam : 'callback',
                url: 'http://upcoming.yahooapis.com/services/rest/',
                listeners : {
                    beforeload : function(s, params) {
                        params.min_date = params.min_date.format('Y-m-d');
                        params.max_date = params.max_date.format('Y-m-d');
                    }
                }
            }),
            baseParams : {
                location:"37.765, -122.396",
                format : 'json',
                api_key :'8df6674b86',
                method : 'event.search',
                per_page:40,
                variety:1
            },
            sortInfo:{field: 'ResourceId', direction: "ASC"},
            idProperty : 'Id',
            root : 'rsp.event',
            fields : [
                {name: 'Id', type:'string', mapping: 'id'},
                {name: 'ResourceId', mapping: 'category_id'},
                {name: 'Title', mapping: 'name'},
                {name: 'Url', mapping: 'url'},
                {name: 'Description', mapping: 'description'},
                {name: 'StartDate', mapping : 'start_date', convert : function(v, r) {
                        var retVal = Date.parseDate(v + ' ' + (r.start_time || '00:00:00'), 'Y-m-d G:i:s');
                        return retVal;
                    }
                },
               {name: 'EndDate', mapping : 'end_date', convert : function(v, r) {
                        var retVal;
                        if (!v) {
                            retVal = Date.parseDate(r.start_date + ' ' + (r.start_time || '00:00:00'), 'Y-m-d G:i:s').add(Date.DAY, 1);
                        } else {
                            retVal = Date.parseDate(v + ' ' + (r.end_time || '00:00:00'), 'Y-m-d G:i:s');
                        }
                        
                        return retVal;
                    }
                }
            ]
        });
        
        var g = new Sch.SchedulerPanel({
            resizeHandles : 'none',
            enableEventDragDrop : false,
            enableDragCreation : false,
            border : true,
            height:600,
            width:1000,
            renderTo : 'grid-upcoming',
            disableSelection : true,
            startParamName : 'min_date',
            endParamName : 'max_date',
            trackMouseOver : false,
            region : 'center',
            stripeRows : true,
            
            // Setup static columns
            columns : [
               {header : 'Category', sortable:true, width:170, dataIndex : 'Name'},
               {header : 'Description', sortable:true, width:170, dataIndex : 'Description'}
            ],
            
            viewConfig : {
                forceFit:true
            },
            
            store : eventCategoryStore,
            eventStore : eventStore,
            
             // Setup your view configuration
            autoViews : [
                {
                    // Timespan <= 1 week show day columns
                    timeSpan : 7, 
                    columnType : 'day',
                    renderer : this.renderer
                }
            ],     
            tbar : [
                {
                    iconCls : 'icon-prev',
                    scale : 'medium',
                    handler : function() {
                        var start = g.getStart(),
                            end = g.getEnd(),
                            days = Date.getDurationInDays(start, end);
                            
                        g.eventStore.load({
                            params : {
                                min_date : start.add(Date.DAY, -days),
                                max_date : start
                            }
                        });
                    }
                },
                {
                    xtype : 'tbtext',
                    text : '<img src="../../images/loading2.gif" id="loader" style="display:none"/>'
                },
                '->',
                {
                    iconCls : 'icon-next',
                    scale : 'medium',
                    handler : function() {
                        var start = g.getStart(),
                            end = g.getEnd(),
                            days = Date.getDurationInDays(start, end);
                                                        
                        g.eventStore.load({
                            params : {
                                min_date : end,
                                max_date : end.add(Date.DAY, days)
                            }
                        });
                    }
                }
            ]
        });
        
        return g;
    }
};
