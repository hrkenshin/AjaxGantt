/*
 *  gantt.js is the main code file for the Gantt Chart control.
 *  
 *  Written on 5/20/2008 by Robert Miller for Delphic Sage
 *  http://www.delphicsage.com/
*/


/*
 *  Things to do:
 *  
 *  - The chart does not scale well with font size. The
 *    tables and grid scale ok, but the task bars do not.
 *    The horizontal spacing also assumes 20 pixels per
 *    square on the grid.
 *    
 *    It scales a little better now, but still needs work.
 *    
 *    
 *  - Create an interface for adding/modifying tasks. Some
 *    of the code for this has been written, but is currently
 *    commented out (search for "Chart / Data Links" in this
 *    document to find the commented out code).
 *  
 *  - If the chart's constructor is given no parameters, no
 *    HTML elements will be generated but the chart logic will
 *    still exist so the code for scheduling tasks can be
 *    accessed even though there is no graphical display.
 *  
 *  - Add an option (for tasks) that determines whether or
 *    not they can be worked on during the weekends. Currently,
 *    no tasks can be worked on during weekends.
*/

DS.GanttTask = function(name, duration)
{
  this.name = name;
  this.duration = duration;
  
  this.actual_duration = duration;
  this.actual_start_date = null;
  this.actual_end_date = null;
  
  this.prereqs = [];
  this.start_date = null;
  this.index = -1;
  
  this.bar_div = null;
  this.scheduled = false;
  
  this.requires = function(t)
  {
    this.prereqs[this.prereqs.length] = t;
  };
};

/*
 *  This is what the Gantt Chart will look like
 *  
 *  +-----------+-----+---------------------------+---------------------------+
 *  |           |     |     May 12 to May 18      |     May 19 to May 25      |
 *  +-----------+-----+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
 *  | Task Name | dur | M | T | W | R | F | S | S | M | T | W | R | F | S | S |
 *  +-----------+-----+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
 *  | Task 1    |   1 |#######                                                |
 *  +-----------+-----+-------------------------------------------------------+
 *  | Task 2    |   1 |        ###########                                    |
 *  +-----------+-----+-------------------------------------------------------+
 *  | Task 3    |   1 |                            ###                        |
 *  +-----------+-----+-------------------------------------------------------+
 *    ...
 *  +-----------+-----+-------------------------------------------------------+
 *  | Task n    |   1 |                                                       |
 *  +-----------+-----+---+------------+----------------------------------+---+
 *                    | < |     ||     |                                  | > |
 *                    +---+------------+----------------------------------+---+
 *  
 *  
 *  The elements are structed like so:
 *  
 *  +----------------------------------------+
 *  |  DIV - parent_div                      |
 *  | +-------------+ +--------------------+ |
 *  | |    TABLE    | |  DIV - chart_div   | |
 *  | |  task_list  | | +----------------+ | |
 *  | |             | | |  TABLE - grid  | | |
 *  | |             | | |                | | |
 *  | |             | | |                | | |
 *  | |             | | |                | | |
 *  | |             | | |                | | |
 *  | |             | | +----------------+ | |
 *  | |             | +---+------+-----+---+ |
 *  | |             | | < |  ||  |     | > | |
 *  | +-------------+ +---+------+-----+---+ |
 *  +----------------------------------------+
 *  
 *  chart_div has a fixed width and its overflow is set to
 *  auto so that the grid (which is most likely much larger
 *  than chart_div) can be scrolled.
 *  
 *  task_list and grid are tables whose rows should line up.
 *  the tasks are listed in a separate table (separate from
 *  grid) so when the grid is scrolled, the task names aren't
 *  scrolled out of view.
 *  
*/

// the parameter is called id, but it can either be an ID
// of an HTML element or a reference to the element.
DS.GanttChart = function(id)
{
  var self = this;
  
  /*
   *  public properties
  */
  this.width = 480;
  this.allow_tooltip_copy = true;
  this.show_tooltips = true;
  
  // used for positioning the bars that represent the tasks
  // so that they scroll with the 
  this.cell_height = 0;
  this.cell_width = 0;
  
  this.parent_div = null;
  
  if(typeof id == "string")
    this.parent_div = $(id);
  else
    this.parent_div = id;
  this.parent_div.style.position = "relative";
  this.parent_div.className = "gantt-chart";
  
  /*
   *  task_list is the table along the left size of the
   *  control that lists the task names and durations.
  */
  this.task_list = document.createElement("table");
  this.task_list.setAttribute("cellSpacing", 0);
  
  this.task_list.style.position = "absolute";
  this.task_list.style.left = "0px";
  this.task_list.style.top = "0px";
  
  this.task_list.style.borderLeftStyle = this.task_list.style.borderRightStyle = this.task_list.style.borderTopStyle = "solid";
  this.task_list.style.borderWidth = "1px";
  this.task_list.style.borderColor = "#000";
  
  this.chart_div = document.createElement("div");
  this.chart_div.style.position = "absolute";
  this.chart_div.style.left = "100px";
  this.chart_div.style.top = "0px";
  
  this.chart_div.style.borderStyle = "solid";
  this.chart_div.style.borderWidth = "1px";
  this.chart_div.style.borderColor = "#000";
  
  this.chart_div.innerHTML = "&nbsp;";
  this.chart_div.style.overflow = "auto";
  
  this.parent_div.appendChild(this.task_list);
  this.parent_div.appendChild(this.chart_div);
  
  this.grid = document.createElement("table");
  this.grid.setAttribute("cellSpacing", "0");
  
  this.grid.style.position = "absolute";
  this.grid.style.left = "0px";
  this.grid.style.top = "0px";
  
  this.chart_div.appendChild(this.grid);
  
  this.start_date = new Date();
  this.end_date = null;
  this.tasks = [];
  
  this.grid.appendChild(document.createElement("tbody"));
  this.task_list.appendChild(document.createElement("tbody"));
  
  
  /*
   *  
  */
  this.copy_text = document.createElement("textarea");
  this.copy_text.style.position = "relative";
  this.copy_text.style.top = "-30px";
  this.copy_text.style.left = "10px";
  this.copy_text.style.width = "1px";
  this.copy_text.style.height = "1px";
  this.copy_text.style.zIndex = "-1";
  this.parent_div.parentNode.appendChild(this.copy_text);
  
  this.parent_div.onmouseup = function()
  {
    self.copy_text.focus();
    self.copy_text.select();
  }
  
  /*
   *  Chart / Data Links
   *  
   *  These links allow the user to switch back and forth
   *  between viewing the tasks in chart form and data form.
   *  Chart form schedules all tasks and shows a graphical
   *  display of the tasks. Data form allows the user to enter
   *  and modify the tasks.
  */
  /*
  this.current_page = "chart";
  
  this.links_div = document.createElement("div");
  this.links_div.style.position = "absolute";
  
  this.chart_link = document.createElement("a");
  this.chart_link.innerHTML = "Chart"
  this.chart_link.href = "javascript:void(0);";
  this.chart_link.onclick = function()
  {
    if(self.current_page == "chart") return;
    
    self.chart_div.style.display = "";
    self.data_div.style.display = "none";
    
    self.current_page = "chart";
  };
  
  this.data_link = document.createElement("a");
  this.data_link.innerHTML = "Data";
  this.data_link.href = "javascript:void(0);";
  this.data_link.onclick = function()
  {
    if(self.current_page == "data") return;
    
    self.chart_div.style.display = "none";
    self.data_div.style.display = "";
    
    self.current_page = "data";
  };
  
  this.links_div.appendChild(this.chart_link);
  this.links_div.appendChild(document.createTextNode(" - "));
  this.links_div.appendChild(this.data_link);
  
  this.parent_div.appendChild(this.links_div);
  */
  
  //  ---- Walter Zorn's jsGraphics library ----
  // http://www.walterzorn.com/jsgraphics/jsgraphics_e.htm
  this.wz_canvas = new jsGraphics(this.chart_div);
  this.wz_canvas.setColor("#3C6083");
  this.wz_canvas.setStroke(1);
  
  
  //  ---- Initialize Tooltip ----
  this.tooltip_div = document.createElement("div");
  this.tooltip_div.id = "task-bar-tooltip";
  this.tooltip_div.className = "gantt-tooltip";
  
  this.parent_div.appendChild(this.tooltip_div);
  this.tooltip = null;
  if(DS.Tooltip)
    this.tooltip = new DS.Tooltip("task-bar-tooltip");
  else
    this.show_tooltips = false;
  
  this.grid.onmouseout = function()
  {
    if(self.tooltip != null)
      self.tooltip.hide();
    for(var i = 0; i < self.tasks.length; i++)
    {
      self.tasks[i].bar_div.className = "gantt-task-bar";
      // self.tasks[i].bar_div.style.background = "url(\"task-bar.png\")";
      // self.tasks[i].bar_div.style.borderColor = "#507FAD";
    }
    self.clear_task_highlights();
  };
  
  
  //  ---- Begin method definitions ----
  
  this.schedule = function()
  {
    var start = new Date(this.start_date.getTime());
    
    // make a copy of the list of tasks and mark
    // all tasks as "unscheduled"
    var tasks_to_schedule = [];
    for(var i = 0; i < this.tasks.length; i++)
    {
      this.tasks[i].index = i;
      if(this.tasks[i].bar_div != null)
        this.tasks[i].bar_div.parentNode.removeChild(this.tasks[i].bar_div);
      tasks_to_schedule[i] = this.tasks[i];
      tasks_to_schedule[i].scheduled = false;
    }
    
    var tasks_scheduled = 0;
    
    // this loop is exited when no task can be scheduled.
    // there are two reasons why this situation can occur:
    // either there are no more unscheduled tasks, or of
    // the remaining tasks, none have all prereqs met. The
    // first case means that we're done, the second case
    // means there's a circular dependency.
    while(true)
    {
      // find a task such that all of its prereqs are met...
      
      // task will be the task to schedule
      var task = null;
      
      // starting date is the last ending date of all prereqs
      // of task. this is the date on which task will begin.
      var starting_date;
      
      for(var i = 0; i < tasks_to_schedule.length; i++)
      {
        if(tasks_to_schedule[i].scheduled) continue;
        
        starting_date = new Date(this.start_date.getTime());
        
        var prereqs_met = true;
        for(var t = 0; t < tasks_to_schedule[i].prereqs.length; t++)
        {
          if(!tasks_to_schedule[i].prereqs[t].scheduled)
          {
            prereqs_met = false;
            break;
          }
          else if(tasks_to_schedule[i].prereqs[t].actual_end_date > starting_date)
            starting_date = tasks_to_schedule[i].prereqs[t].actual_end_date;
        }
        
        if(prereqs_met)
        {
          task = tasks_to_schedule[i];
          break;
        }
      }
      
      // if task is null either all tasks are scheduled
      // or no more tasks can be scheduled.
      if(task == null)
      {
        // if there are unscheduled tasks...
        if(tasks_scheduled < this.tasks.length)
        {
          var task_list = "\n";
          for(var t = 0; t < tasks_to_schedule.length; t++)
          {
            if(!tasks_to_schedule[t].scheduled)
              task_list += "\n\t\t" + tasks_to_schedule[t].name;
          }
          alert("Some of the tasks contain prerequisites that form a circular dependence.\nBecause of this, the following tasks could not be scheduled:" + task_list);
        }
        break;
      }
      
      // if the starting date is on a weekend, move it up to the next monday
      while(starting_date.getDay() == 0 || starting_date.getDay() == 6)
        starting_date.setTime(starting_date.getTime() + 1000 * 60 * 60 * 24);
      
      // schedule task to begin on starting_date
      task.actual_start_date = new Date(starting_date.getTime());
      var end_date = new Date(starting_date.getTime());
      
      // weekend days that lie between the task's start
      // and end dates don't count towards its duration,
      // so for each such day add one to the task's
      // actual duration.
      task.actual_duration = task.duration;
      for(var d = 0; d < task.actual_duration; d++)
      {
        if(end_date.getDay() == 0 || end_date.getDay() == 6)
          task.actual_duration += 1;
        end_date.setTime(end_date.getTime() + 1000 * 60 * 60 * 24);
      }
      
      task.actual_end_date = end_date;
      task.scheduled = true;
      tasks_scheduled += 1;
    }
    
    // find the last ending date to compute how many weeks
    // the project spans so the grid can be generated.
    
    var ending_date = null;
    for(var i = 0; i < this.tasks.length; i++)
    {
      if(ending_date == null)
        ending_date = this.tasks[i].actual_end_date;
      else
      {
        if(this.tasks[i].actual_end_date > ending_date)
          ending_date = this.tasks[i].actual_end_date;
      }
    }
    this.end_date = new Date(ending_date.getTime());
    
    var time_span = ending_date.getTime() - this.start_date.getTime();
    time_span /= 1000 * 60 * 60 * 24 * 7;
    // this.resize();
    
    this.set_grid(Math.floor(time_span + 1.5));
    
    for(var i = 0; i < this.tasks.length; i++)
    {
      this.draw_task_bar(this.tasks[i].index, this.tasks[i].actual_start_date);
    }
    
    this.wz_canvas.clear();
    for(var t = 0; t < this.tasks.length; t++)
    {
      var _task = this.tasks[t];
      for(var p = 0; p < _task.prereqs.length; p++)
      {
        var prereq = _task.prereqs[p];
        
        var px = +prereq.bar_div.style.left.replace("px", "") + +prereq.bar_div.style.width.replace("px", "") + 1;
        var py = +prereq.bar_div.style.top.replace("px", "") + 8;
        
        var tx = +_task.bar_div.style.left.replace("px", "");
        var ty = +_task.bar_div.style.top.replace("px", "") + 8;
        
        px -= DS.IE * 2;
        // tx -= DS.IE;
        
        this.wz_canvas.drawLine(px, py, tx, ty);
      }
    }
    this.wz_canvas.paint();
  };
  
  this.draw_task_bar = function(index, start_date)
  {
    var div = document.createElement("div");
    this.tasks[index].bar_div = div;
    div.className = "gantt-task-bar";
    
    div.style.width = (this.cell_width * Math.floor(this.tasks[index].actual_duration) - 1 + DS.IE * 2) + "px";
    
    var h_offset = Math.floor((this.cell_height - 17) / 2) + DS.IE;
    
    var days_offset = Math.floor((start_date.getTime() - this.start_date.getTime()) / (1000 * 60 * 60 * 24) + this.start_date.getDay()) - 1;
    div.style.left = (days_offset * this.cell_width - 1) + "px";
    div.style.top = Math.floor((2 + index) * this.cell_height + h_offset - DS.IE) + "px";
    div.style.height = (15 + DS.IE * 2) + "px";
    
    div.onmouseover = function()
    {
      // highlight this task bar div, and the bars for all
      // of its preqreqs.
      
      // reset all task bar div backgrounds...
      for(var i = 0; i < self.tasks.length; i++)
      {
        self.tasks[i].bar_div.className = "gantt-task-bar";
        // self.tasks[i].bar_div.style.background = "url(\"task-bar.png\")";
        // self.tasks[i].bar_div.style.borderColor = "#507FAD";
      }
      self.clear_task_highlights();
      
      // trace back all prereqs and set the background of each one
      var prereqs = [self.tasks[index]];
      var _index = 0;
      while(_index < prereqs.length)
      {
        var task = prereqs[_index];
        
        task.bar_div.className = "gantt-task-bar-light";
        // task.bar_div.style.background = "url(task-bar-light.png)";
        // task.bar_div.style.borderColor = "#5C93C8";
        self.highlight_task(task.index);
        
        for(var i = 0; i < task.prereqs.length; i++)
        {
          prereqs[prereqs.length] = task.prereqs[i];
        }
        
        _index += 1;
      }
      
      if(!self.show_tooltips) return;
      
      // show the tooltip
      var left = days_offset * self.cell_width - self.chart_div.scrollLeft + self.task_list.scrollWidth;
      if(left < self.task_list.scrollWidth)
        left = self.task_list.scrollWidth;
      var t = self.tasks[index];
      
      var msg = t.name + ": " + t.actual_start_date.format("MMM d");
      
      // if the end date is the same as the start date, only
      // display one date in the tooltip. otherwise, display
      // the date range.
      // 
      // t.actual_end_date is the first day after the task has
      // been completed, so the tooltip should display:
      // actual_start_date to (actual_end_date - 1 day)
      
      var end_date = new Date(t.actual_end_date.getTime() - 1000 * 60 * 60 * 24);
      
      while(end_date.getDay() == 0 || end_date.getDay() == 6)
        end_date.setTime(end_date.getTime() - 1000 * 60 * 60 * 24);
      
      if(end_date.getDate() != t.actual_start_date.getDate() ||
         end_date.getMonth() != t.actual_start_date.getMonth() ||
         end_date.getYear() != t.actual_start_date.getYear())
        msg += " - " + end_date.format("MMM d");
      
      if(t.prereqs.length == 1)
        msg += "<br/>Requirement: ";
      else
        msg += "<br/>Requirements: ";
      
      if(t.prereqs.length == 0)
        msg += "none";
      else
      {
        var req_str = "";
        for(var i = 0; i < t.prereqs.length; i++)
        {
          if(req_str != "") req_str += ", ";
          req_str += t.prereqs[i].name;
        }
        msg += req_str;
      }
      
      if(self.allow_tooltip_copy)
      {
        self.copy_text.value = msg.replace("<br/>", "\n");
        msg += "<br/><small>Press Ctrl + C to Copy</small>";
      }
      
      self.tooltip.show(left, (2 + index) * self.cell_height, msg, "top-right"); // "top-right");
      self.tooltip.show(left, (2 + index) * self.cell_height, msg, "top-right"); // "top-right");
      
      self.copy_text.focus();
      self.copy_text.select();
    };
    
    this.chart_div.appendChild(div);
  };
  
  this.init = function()
  {
    self.add_task_row("&nbsp;", "&nbsp;");
    self.add_task_row("Task Name", "dur");
    
    disable_text_selecting(self.parent_div);
    this.resize();
  };
  
  this.set_grid = function(num_weeks)
  {
    this.chart_div.style.width = "";
    this.parent_div.style.width = "";
    
    var start_date = new Date(this.start_date.getTime());
    
    while(start_date.getDay() != 1)
      start_date.setTime(start_date.getTime() - 1000 * 60 * 60 * 24);
    
    while(this.grid.firstChild.childNodes.length > 0)
      this.grid.firstChild.removeChild(this.grid.firstChild.childNodes[0]);
    
    this.cell_width = 23;
    this.grid.style.width = (this.cell_width * 7 * num_weeks) + "px";
    
    var d = new Date(start_date.getTime());
    
    var header1_tr = document.createElement("tr");
    for(var i = 0; i < num_weeks; i++)
    {
      var td = document.createElement("td");
      td.className = "gantt-chart";
      td.setAttribute("colSpan", 7);
      var label = d.format("MMM d") + " to ";
      
      d.setTime(d.getTime() + 1000 * 60 * 60 * 24 * 6);
      label += d.format("MMM d");
      d.setTime(d.getTime() + 1000 * 60 * 60 * 24 * 1);
      
      td.innerHTML = "<nobr>" + label + "</nobr>";
      
      header1_tr.appendChild(td);
    }
    
    var days_of_week = ["M", "T", "W", "R", "F", "S", "S"];
    var header2_tr = document.createElement("tr");
    for(var i = 0; i < num_weeks; i++)
    {
      for(var a = 0; a < days_of_week.length; a++)
      {
        var td = document.createElement("td");
        td.className = "gantt-chart";
        td.innerHTML = days_of_week[a];
        header2_tr.appendChild(td);
      }
    }
    
    this.grid.firstChild.appendChild(header1_tr);
    this.grid.firstChild.appendChild(header2_tr);
    
    for(var x = 0; x < this.tasks.length; x++)
    {
      var header3_tr = document.createElement("tr");
      header3_tr.name = "" + x;
      
      for(var i = 0; i < num_weeks; i++)
      {
        for(var a = 0; a < days_of_week.length; a++)
        {
          var td = document.createElement("td");
          td.innerHTML = "&nbsp;";
          
          if(a >= 5)
            td.className = "gantt-grid-weekend";
          else
            td.className = "gantt-grid-weekday";
          
          header3_tr.appendChild(td);
        }
      }
      this.grid.firstChild.appendChild(header3_tr);
    }
    this.resize();
  };
  
  this.add_task = function(task)
  {
    this.tasks[this.tasks.length] = task;
    this.add_task_row(task.name, task.duration);
  }
  
  this.add_task_row = function(task_name, duration)
  {
    var tr = document.createElement("tr");
    
    var td1 = document.createElement("td");
    td1.className = "task-list";
    td1.innerHTML = task_name;
    
    var td2 = document.createElement("td");
    td2.className = "task-duration";
    td2.innerHTML = duration;
    
    tr.appendChild(td1);
    tr.appendChild(td2);
    
    self.task_list.firstChild.appendChild(tr);
    self.resize();
    self.clear_task_highlights();
  };
  
  this.resize = function()
  {
    var tasks_list_width = this.task_list.scrollWidth;
    var tasks_list_height = this.task_list.scrollHeight;
    
    this.cell_height = tasks_list_height / (this.tasks.length + 2);
    
    this.chart_div.style.left = (tasks_list_width - 1 + 2 * DS.IE) + "px";
    
    this.chart_div.style.height = (tasks_list_height + 15 + 3 * DS.IE) + "px";
    this.chart_div.style.width = this.width + "px";
    
    // this.links_div.style.left = "6px";
    // this.links_div.style.top = (tasks_list_height + 2) + "px";
    
    this.parent_div.style.width = (tasks_list_width + this.width) + "px";
    this.parent_div.style.height = (tasks_list_height + 15) + "px";
  };
  
  this.clear_task_highlights = function()
  {
    for(var i = 0; i < self.task_list.firstChild.childNodes.length; i++)
    {
      self.task_list.firstChild.childNodes[i].style.color = "#000";
    }
  };
  
  this.highlight_task = function(index)
  {
    self.task_list.firstChild.childNodes[index + 2].style.color = "#5C93C8"; // "#000";
  };
  
  /*
   *  toXML returns a string of XML representing the
   *  tasks contained in the chart. The structure of
   *  the XML is as follows:
   *  
   *  <tasks>
   *      <task name="Task 1" duration="3">
   *          <task name="Task 2" duration="2"/>
   *      </task>
   *      <task name="Task 3" duration="1"/>
   *  </tasks>
   *  
   *  The name, duration, and other properties for
   *  each task are stored in attributes of each
   *  <task> tag. The prerequisite relationship
   *  is captured by the nesting of the <task> tags.
   *  Child nodes are prereqs of the parent. So, in
   *  the XML above, Task 2 and Task 3 have no
   *  prereqs, but Task 2 is a prereq of Task 1.
   *  
   *  Problem: tags would have to be duplicated because
   *           one task may be a prereq for two different
   *           tasks, and would therefore have to be a
   *           child of both. each tag would need an "id",
   *           so that such duplicate tags can be identified
   *           since task names aren't guaranteed to be
   *           unique.
  */
  this.toXML = function()
  {
    var xml = "<tasks>";
    
    xml += "</tasks>";
    return xml;
  };
  
  this.init();
};