/*
 *  main.js includes some general functions used by our other JavaScript libraries.
 *  
 *  Written on 5/20/2008 by Robert Miller for Delphic Sage
 *  http://www.delphicsage.com/
*/


var DS = {};

DS.IE = (window.ActiveXObject) ? 1 : 0;
DS.opera = (window.opera) ? 1 : 0;

function $(id) { return document.getElementById(id); }

function get_bounds(elm)
{
  var get_pos = function(el, x, y)
  {
    if(!x) { x = 0; y = 0; }
    
    if(el && el.offsetParent)
      return get_pos(el.offsetParent, x + el.offsetLeft, y + el.offsetTop);
    else
      return {left: x + el.offsetLeft, top: y + el.offsetTop };
  }
  
  var bounds = get_pos(elm);
  bounds.right = bounds.left + elm.clientWidth;
  bounds.bottom = bounds.top + elm.clientHeight;
  
  return bounds;
}

function disable_text_selecting(el)
{
  el.onselectstart = function() { return false; };
  el.unselectable = "on";
  el.style.MozUserSelect = "none";
  el.onmousedown = function() { return false; };
}

function enable_text_selecting(el)
{
  el.onselectstart = function() { return true; };
  el.unselectable = undefined;
  el.style.MozUserSelect = "";
}

Array.prototype.remove = function(from, to)
{
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this, rest);
};